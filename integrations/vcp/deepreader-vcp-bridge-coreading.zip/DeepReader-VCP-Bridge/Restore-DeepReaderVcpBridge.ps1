[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$VcpRoot,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$BackupRoot
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Resolve-ExistingDirectory([string]$PathValue) {
    $resolved = Resolve-Path -LiteralPath $PathValue -ErrorAction Stop
    $item = Get-Item -LiteralPath $resolved.Path -Force
    if (-not $item.PSIsContainer) {
        throw "Expected an existing directory: $PathValue"
    }
    return $item.FullName
}

function Get-NormalizedRelativePath([string]$PathValue) {
    $normalized = $PathValue.Replace(
        [System.IO.Path]::AltDirectorySeparatorChar,
        [System.IO.Path]::DirectorySeparatorChar
    )
    return $normalized.TrimStart([char[]]@([System.IO.Path]::DirectorySeparatorChar))
}

$AllowedPayloadFiles = @(
    'Plugin\VCPBridgeServer\bridgeConfig.js',
    'Plugin\VCPBridgeServer\bridgeConfig.test.js',
    'Plugin\VCPBridgeServer\bridgeserver.js',
    'Plugin\VCPBridgeServer\bridgeserver.test.js',
    'Plugin\VCPBridgeServer\config.env.example',
    'Plugin\VCPBridgeServer\coreading.txt',
    'Plugin\VCPBridgeServer\plugin-manifest.json',
    'Plugin\VCPBridgeServer\profiles\coreading.json'
) | ForEach-Object { Get-NormalizedRelativePath $_ }

$ResolvedVcpRoot = Resolve-ExistingDirectory $VcpRoot
$ResolvedBackupRoot = Resolve-ExistingDirectory $BackupRoot
$statePath = Join-Path $ResolvedBackupRoot 'installation-state.json'

if (-not (Test-Path -LiteralPath $statePath -PathType Leaf)) {
    throw "Backup state file is missing: $statePath"
}

$state = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
if ($state.schemaVersion -ne 1 -or -not $state.files) {
    throw 'Unsupported or invalid installation-state.json.'
}

if ($WhatIfPreference) {
    Write-Host '[WhatIf] The following installed files would be restored or removed:'
    foreach ($entry in $state.files) {
        Write-Host ("  {0} (existed before install: {1})" -f $entry.relativePath, $entry.existed)
    }
    return
}

foreach ($entry in $state.files) {
    $relativePath = Get-NormalizedRelativePath ([string]$entry.relativePath)
    if ([System.IO.Path]::IsPathRooted($relativePath) -or $AllowedPayloadFiles -notcontains $relativePath) {
        throw "Unsafe or unexpected relative path in backup state: $relativePath"
    }

    $targetPath = Join-Path $ResolvedVcpRoot $relativePath
    $backupPath = Join-Path $ResolvedBackupRoot $relativePath

    if ([bool]$entry.existed) {
        if (-not (Test-Path -LiteralPath $backupPath -PathType Leaf)) {
            throw "Expected backup file is missing: $relativePath"
        }
        New-Item -ItemType Directory -Path (Split-Path -Parent $targetPath) -Force | Out-Null
        Copy-Item -LiteralPath $backupPath -Destination $targetPath -Force
    }
    elseif (Test-Path -LiteralPath $targetPath -PathType Leaf) {
        Remove-Item -LiteralPath $targetPath -Force
    }
}

Write-Host ''
Write-Host 'DeepReader VCP Bridge payload restored successfully.' -ForegroundColor Green
Write-Host 'No config.env, bridge-config.json, database, diary or memory file was changed.'
Write-Host 'No process was stopped or restarted. Verify the exact 3100/PM2 process before manually restarting it.'
