# DeepReader × VCP Bridge 自动共读集成包

本归档用于把已验证的 `VCPBridgeServer` 自动共读实现安装到一个**现有的 VCPToolBox 仓库**，并让 DeepReader 通过 `coreading` Profile 调用它。

它解决的重点问题是：自动共读第一页成功后，第二页因为正文、最近阅读、滚动摘要、AI 批注或 RAG 日记/记忆召回中出现占位符样式的普通文字，被旧版 Bridge 误判为 Profile Prompt 仍有未展开的 VCP 原生占位符。

> 本归档不是独立服务器，也不包含 VCP 主程序、模型账户、API Key、私人日记、记忆库、数据库或任何本机 Provider 配置。请先安装并能正常启动 VCPToolBox。

## 1. 归档内容

```text
DeepReader-VCP-Bridge/
├─ README.md
├─ Install-DeepReaderVcpBridge.ps1
├─ Restore-DeepReaderVcpBridge.ps1
├─ MANIFEST.sha256
├─ SOURCE.txt
├─ LICENSE-VCP.txt
└─ Plugin/
   └─ VCPBridgeServer/
      ├─ bridgeConfig.js
      ├─ bridgeConfig.test.js
      ├─ bridgeserver.js
      ├─ bridgeserver.test.js
      ├─ config.env.example
      ├─ coreading.txt
      ├─ plugin-manifest.json
      └─ profiles/
         └─ coreading.json
```

其中：

- `bridgeserver.js`：Bridge 运行实现，包括 OpenAI-compatible 路由、Profile 选择、VCP 原生预处理接入和 Prompt 占位符来源追踪；
- `bridgeConfig.js`：安全读取 `bridge-config.json`、Profile 和 Prompt 文件；
- `coreading.txt`：Nova 自动共读 Prompt，保留人格、时间线、只读日记/记忆召回和 MemoToolBox 上下文；
- `profiles/coreading.json`：DeepReader 自动共读使用的独立 Profile；
- `*.test.js`：Bridge 配置、协议和占位符来源追踪回归测试；
- 安装与恢复脚本：只处理固定白名单文件，不写入密钥，也不自动停止或重启任何 Node/PM2 进程。

## 2. 兼容前提

建议使用较新的 VCPToolBox 工作树。安装脚本会检查目标 VCP 根目录至少具有：

```text
package.json
server.js
modules/messageProcessor.js
Plugin/RAGDiaryPlugin/RAGDiaryPlugin.js
preprocessor_order.json
```

Bridge 使用宿主 VCP 的原生变量、时间线、日记、记忆和其他消息预处理器。本归档**不会覆盖**上述宿主核心文件，因此不能把它解压到空目录后当作独立程序运行。

宿主 Node 依赖中应已有：

```text
express
dotenv
chokidar
```

如果 VCP 根目录尚未安装依赖，请先按 VCP 项目自己的说明执行依赖安装和基础配置。

## 3. 安装

### 3.1 解压归档

把 ZIP 解压到任意临时目录。不要直接把 ZIP 内容覆盖到 VCP 根目录；先运行安装脚本，让脚本完成前置检查和备份。

### 3.2 运行安全安装脚本

在 PowerShell 中执行：

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\Install-DeepReaderVcpBridge.ps1 -VcpRoot "D:\path\to\VCPToolBox"
```

安装脚本会：

1. 将 `VcpRoot` 解析为真实目录；
2. 检查 VCP 宿主文件和 Node 依赖；
3. 校验归档 `MANIFEST.sha256`；
4. 在 VCP 根目录的 `backups\deepreader-vcp-bridge-<时间戳>` 下备份即将被覆盖的文件；
5. 只复制本归档列出的 8 个插件白名单文件；
6. 写入 `installation-state.json`，供恢复脚本判断哪些文件原先存在；
7. **不**修改根 `config.env`；
8. **不**覆盖现有 `Plugin/VCPBridgeServer/bridge-config.json`；
9. **不**停止、重启或批量终止 Node.js/PM2 进程。

可以先预演，不写入 VCP：

```powershell
.\Install-DeepReaderVcpBridge.ps1 -VcpRoot "D:\path\to\VCPToolBox" -WhatIf
```

安装成功后请记下脚本打印的备份目录。

## 4. VCP 配置

### 4.1 根 `config.env`

VCP 的模型 Provider、主服务 Key 和其他真实配置仍由 VCP 根目录的 `config.env` 管理。不要把该文件提交到 Git，也不要把内容粘贴到公开 issue 或日志中。

`coreading.txt` 保留了 Nova 时间线占位符：

```text
{{VarTimelineNova}}
```

因此根 `config.env` 中必须提供非空的 `VarTimelineNova`。推荐让它引用 VCP 的 `TVStxt` 文件，而不是把很长的时间线直接写进环境文件。例如，按你的 VCP 版本和目录约定配置一个文件名，并确认对应文件真实存在。

Prompt 还包含日记/记忆占位符：

```text
[[Nova日记本::Time::Group::TagMemo+]]
[[Nova的知识日记本::Time::Group::TagMemo+]]
[[公共的日常|公共的知识日记本::Group::Time::TagMemo+]]
[[阅读器日记本::Time::Group::TagMemo+]]
{{VCPMemoToolBox}}
```

这些能力只作为自动共读的**只读上下文**。普通自动共读轮禁止写日记、禁止主动输出工具协议。若你的 VCP 部署没有相应日记本，请按 VCP 的日记/记忆配置规则创建或调整 Prompt；不要保留一个无法由宿主展开的原生 Prompt token。

### 4.2 `bridge-config.json`

安装脚本有意不覆盖该文件，因为它可能包含你的本机端口、上游和模型配置。

如果该文件不存在，VCPBridgeServer 首次启动会根据插件的 `config.env.example` 或默认值创建。请在启动前或通过你自己的 VCP 管理入口确认以下非敏感配置：

```json
{
  "port": 3100,
  "upstreamUrl": "http://127.0.0.1:6005",
  "upstreamKey": "",
  "upstreamType": "chat",
  "defaultModel": "gpt-5.6-sol",
  "systemPrompt": "",
  "hijackMode": "off",
  "modelMap": {},
  "availableModels": ["gpt-5.6-sol"],
  "modelsTimeoutMs": 3000,
  "debugMode": false,
  "defaultProfile": ""
}
```

说明：

- `3100` 是 Bridge 监听端口；
- `6005` 是示例 VCP 主服务端口；如果你的主服务端口不同，请按实际环境修改；
- `upstreamKey` 留空时，Bridge 可使用 VCP 主服务 Key 或按现有实现处理下游 Authorization；不要在公开文件中硬编码真实 Key；
- `defaultModel` 只是请求未提供模型时的兜底；DeepReader 通常会显式发送模型；
- `coreading` Profile 已由 `profiles/coreading.json` 提供，不需要把它设为全局默认 Profile。

Profile 和 Prompt 会在请求时安全读取；新增、修改或删除 Profile 通常可热生效。监听端口变化需要精确重启 Bridge/VCP 服务。

## 5. DeepReader 配置

在 DeepReader 的 OpenAI-compatible Provider / VCP Bridge 设置中填写：

```text
Bridge URL:   http://127.0.0.1:3100/v1/coreading/chat/completions
Profile:      coreading
Header:       X-Bridge-Profile: coreading
Request model: coreading/gpt-5.6-sol
```

实际模型名请替换为你的 VCP 上游支持的模型。当前 Bridge 在 URL 或 Header 已选中 `coreading` 时，会把请求模型：

```text
coreading/gpt-5.6-sol
```

转发为：

```text
gpt-5.6-sol
```

不要把模型服务 Key 写进仓库。DeepReader 中使用的 Key 应当是你本机 VCP 部署允许的本地访问凭据。

### 5.1 当前请求字段

自动共读使用：

```text
CURRENT_VISIBLE_FOCUS
RECENT_READ_BLOCKS
ROLLING_SUMMARY
RECENT_AI_ANNOTATIONS
```

不要恢复已废弃字段：

```text
NEW_BLOCKS
CURRENT_READING_BUNDLE
```

### 5.2 响应契约

顶层响应只能是：

```json
{
  "summary": "连续、不过度剧透的已读摘要",
  "annotations": []
}
```

约束：

- `annotations` 数量为 `0–3`；
- `annotation.blockKey` 必须属于 `CURRENT_VISIBLE_FOCUS`；
- `annotation.quote` 必须逐字存在于对应当前正文块；
- `RECENT_READ_BLOCKS` 只作上下文，不能成为新批注目标；
- 自动共读轮不能写日记、不能输出工具请求块或其他协议；
- 没有值得保存的具体触发点时允许返回空 `annotations`。

## 6. 本次占位符修复原理

### 6.1 旧误报路径

旧版 Bridge 在 VCP 预处理结束后扫描**全部最终消息**，因此无法区分：

1. 原本位于 Profile Prompt、必须成功展开的模板 token；
2. 后来由用户正文、最近阅读、滚动摘要、已有批注、日记或记忆召回带入的普通字面文本。

第一页通常没有历史上下文；第二页开始会带入最近阅读、摘要和批注，并可能触发不同的 RAG 召回。因此第二页更容易出现类似 `{{VarExample}}` 的普通文字并触发旧误报。

### 6.2 新来源追踪

新实现按请求执行：

```text
读取 Profile Prompt
→ 只标记 Prompt 注入时已经存在的原生 token
→ 注入 system Prompt
→ 运行 VCP 原生变量、时间线、日记和记忆预处理
→ 只验证最初来自 Profile Prompt 的 token
→ 删除内部来源标记
→ 把正常消息发给上游
```

支持追踪的原生 token 形态：

```text
{{Var...}}
{{Tar...}}
[[...日记本...]]
<<...日记本...>>
《《...日记本...》》
{{...日记本...}}
```

安全行为保持 fail-closed：

- 真正来自 Profile Prompt 的 token 仍未展开：返回 `native_placeholder_unresolved`；
- 来源标记缺失、重复、开闭不匹配或损坏：返回 `native_placeholder_tracking_failed`；
- 用户正文、最近阅读、摘要、批注、日记或记忆召回后来出现的占位符样式普通文字：不再误报为 Prompt 泄漏；
- 内部 `VCP_NATIVE_...` 来源标记不会进入最终上游请求。

本修复没有关闭残留占位符验证，也没有删除 Nova 人格、时间线、日记、记忆或 MemoToolBox 能力。

## 7. 图片页说明

DeepReader 自动共读不会把以下内容作为正文自动发给模型：

```text
img
src
图片字节
base64
alt
canvas
svg
```

`figcaption` 和图片相邻的普通正文可以作为文本进入当前焦点。因此图片本体不是 `native_placeholder_unresolved` 的直接原因；图片页只能通过改变可见文字、第二轮上下文或 RAG 召回而间接暴露旧误报。

## 8. 验证

在 **VCP 根目录**执行。

### 8.1 语法检查

```powershell
node --check Plugin/VCPBridgeServer/bridgeserver.js
node --check Plugin/VCPBridgeServer/bridgeConfig.js
node --check Plugin/VCPBridgeServer/bridgeserver.test.js
node --check Plugin/VCPBridgeServer/bridgeConfig.test.js
```

### 8.2 配置安全测试

```powershell
node --test Plugin/VCPBridgeServer/bridgeConfig.test.js
```

### 8.3 占位符来源追踪定向测试

```powershell
node --test --test-name-pattern="native prompt|native placeholder detection|two consecutive|Bridge follows|final upstream body|ordinary prompt|missing host" Plugin/VCPBridgeServer/bridgeserver.test.js
```

本归档发布前该定向集合结果为：

```text
tests: 9
pass: 9
fail: 0
```

### 8.4 完整 Bridge 测试的已知可选 Profile 前提

```powershell
node --test Plugin/VCPBridgeServer/bridgeserver.test.js
```

发布环境中的完整文件共有 16 项测试；当前本机因为没有授权发布的可选文件：

```text
Plugin/VCPBridgeServer/profiles/deepreader-coreading-diary.json
```

而出现 3 个与本次来源追踪修复无关的既有失败。不要为了让测试数字变绿而随意创建该 Profile，也不要把私有日记配置提交到仓库。占位符修复的发布门槛是上一节 9/9 定向测试通过，并且完整测试没有新增失败类别。

### 8.5 Bridge 健康检查

```powershell
Invoke-RestMethod http://127.0.0.1:3100/health
```

真实请求验证时只使用合成文本；不要把真实书籍、批注、rolling summary、日记或记忆正文输出到共享日志。

## 9. 安全重载

不要硬编码旧 PID，也不要批量终止 Node.js。每次都重新确认：

```powershell
Get-NetTCPConnection -LocalPort 3100 -State Listen |
  Select-Object LocalAddress, LocalPort, OwningProcess
```

如果使用 PM2：

```powershell
pm2 jlist
pm2 describe <已确认的应用名>
```

必须核对：

- 监听 `3100` 的 PID；
- PM2 应用对应同一进程；
- `pm_cwd` 是你的 VCP 根目录；
- `pm_exec_path` 是该目录下的 `server.js`。

只有全部一致后，才执行：

```powershell
pm2 restart <已确认的应用名>
```

严禁使用按名称批量终止 Node.js 的命令，因为同机可能运行 DeepReader 开发服务、Snow AI CLI、AdminPanel 或其他 Node 程序。

## 10. 回滚

使用安装脚本输出的备份目录：

```powershell
.\Restore-DeepReaderVcpBridge.ps1 `
  -VcpRoot "D:\path\to\VCPToolBox" `
  -BackupRoot "D:\path\to\VCPToolBox\backups\deepreader-vcp-bridge-<时间戳>"
```

恢复脚本会根据 `installation-state.json`：

- 恢复安装前已存在的白名单文件；
- 删除安装前不存在、由本归档新增的白名单文件；
- 不修改 `config.env`、`bridge-config.json`、数据库、日记或记忆；
- 不自动重启任何进程。

恢复后仍需按“安全重载”一节重新确认目标进程，再由你手动重启。

## 11. 隐私与安全边界

归档不应包含：

```text
API key
token
secret
Authorization 值
根 config.env
本机 bridge-config.json
Provider 私有配置
真实书籍正文
真实 annotation.quote
rolling summary 正文
日记/记忆正文
数据库
日志
本机固定 PID
```

若你重新打包或修改本归档，请重新解压审计、核对 `MANIFEST.sha256`，并只使用合成数据验证。

## 12. 许可与来源

本归档中的 VCP 派生文件来自 VCPToolBox，并保留其 `Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International` 许可证文本，见 `LICENSE-VCP.txt`。归档仅作为 DeepReader 与 VCPToolBox 的可选集成材料；它不表示 VCP 上游项目对本归档提供官方背书。

来源与打包基线见 `SOURCE.txt`。
