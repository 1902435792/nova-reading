// VCPBridgeServer - System Prompt 劫持代理
// 独立端口运行，拦截 CLI 工具请求，注入/替换 system prompt 后转发到上游 API。
// 支持 OpenAI Chat、Responses API、Anthropic Messages、Gemini 四种协议。

const express = require("express");
const path = require("path");
const fs = require("fs");
const chokidar = require("chokidar");
const messageProcessor = require("../../modules/messageProcessor.js");
const {
  CONFIG_PATH,
  PROFILES_DIR,
  BridgePromptError,
  migrateBridgeConfig,
  normalizeBridgeConfig,
  parseModelMap,
  readSystemPrompt,
  readProfile,
  listProfiles,
} = require("./bridgeConfig");

const PREPROCESSOR_ORDER_PATH = path.resolve(
  __dirname,
  "..",
  "..",
  "preprocessor_order.json"
);
const NATIVE_PROMPT_PLACEHOLDER =
  /\{\{(?:Var|Tar)[A-Za-z0-9_]+\}\}|\[\[[^\]\r\n]*日记本[^\]\r\n]*\]\]|<<[^>\r\n]*日记本[^>\r\n]*>>|《《[^》\r\n]*日记本[^》\r\n]*》》|\{\{[^{}\r\n]*日记本[^{}\r\n]*\}\}/g;

class BridgeNativePromptError extends Error {
  constructor(code, message, statusCode = 422) {
    super(message);
    this.name = "BridgeNativePromptError";
    this.code = code;
    this.statusCode = statusCode;
  }
}

let server = null;
let configWatcher = null;
let profilesWatcher = null;
let runtimeConfig = {};
let profilesCache = new Map();
let hostDependencies = {};
let bridgeOwnedRagProcessor = null;
let bridgeRagInitialization = null;
let fetchTransport = (...args) => fetch(...args);

// ============================================================
// 初始化与生命周期
// ============================================================

function initialize(config, dependencies = {}) {
  if (server) {
    console.warn(
      "[VCPBridgeServer] initialize() called while already running; keeping the existing listener."
    );
    return;
  }
  hostDependencies = dependencies || {};
  const bridgeConfig = migrateBridgeConfig();
  applyBridgeRuntimeConfig(bridgeConfig, config, true);
  startConfigWatcher(config);
  startProfilesWatcher();
  loadAllProfiles();
  startServer();
  console.log(
    `[VCPBridgeServer] Initialized. Hijack mode: ${runtimeConfig.hijackMode}, Port: ${runtimeConfig.port}, Upstream: ${runtimeConfig.upstreamUrl}, Profiles: ${profilesCache.size}`
  );
}

function startProfilesWatcher() {
  if (profilesWatcher) return;
  try {
    const fs_sync = require("fs");
    if (!fs_sync.existsSync(PROFILES_DIR)) {
      fs_sync.mkdirSync(PROFILES_DIR, { recursive: true });
    }
    profilesWatcher = chokidar.watch(PROFILES_DIR, {
      ignoreInitial: true,
      awaitWriteFinish: {
        stabilityThreshold: 250,
        pollInterval: 50,
      },
    });
    const reload = () => loadAllProfiles();
    profilesWatcher.on("add", reload);
    profilesWatcher.on("change", reload);
    profilesWatcher.on("unlink", reload);
    profilesWatcher.on("error", (error) => {
      console.error("[VCPBridgeServer] Profiles watcher error:", error);
    });
  } catch (error) {
    console.error("[VCPBridgeServer] Failed to start profiles watcher:", error);
  }
}

function applyBridgeRuntimeConfig(
  bridgeConfig,
  hostConfig = {},
  isInitial = false
) {
  // 默认上游自动指向本地 VCP 主服务器，无需用户手动配置
  const mainServerPort = hostConfig.PORT || process.env.PORT || 6005;
  const mainServerKey = hostConfig.Key || process.env.Key || "";
  const defaultUpstream = `http://127.0.0.1:${mainServerPort}`;

  const normalized = normalizeBridgeConfig({
    ...bridgeConfig,
    mainServerPort,
    upstreamUrl: bridgeConfig.upstreamUrl || defaultUpstream,
    upstreamKey: bridgeConfig.upstreamKey || mainServerKey,
  });

  const previousPort = runtimeConfig.port;
  runtimeConfig = {
    port: normalized.port,
    upstreamUrl: normalized.upstreamUrl,
    upstreamKey: normalized.upstreamKey,
    upstreamType: normalized.upstreamType,
    defaultModel: normalized.defaultModel,
    systemPrompt: resolveSystemPrompt(normalized.systemPrompt),
    hijackMode: normalized.hijackMode,
    modelMap: parseModelMap(normalized.modelMap),
    availableModels: normalized.availableModels,
    modelsTimeoutMs: normalized.modelsTimeoutMs,
    defaultProfile: normalized.defaultProfile,
    debugMode: normalized.debugMode,
    basePath: hostConfig.PROJECT_BASE_PATH || __dirname,
    configPath: CONFIG_PATH,
  };

  if (!isInitial && previousPort && previousPort !== runtimeConfig.port) {
    console.warn(
      `[VCPBridgeServer] bridge-config.json port changed from ${previousPort} to ${runtimeConfig.port}. Port changes require plugin/server restart.`
    );
  }

  if (!isInitial) {
    console.log(
      `[VCPBridgeServer] Hot config reloaded. Hijack mode: ${runtimeConfig.hijackMode}, Upstream: ${runtimeConfig.upstreamUrl}`
    );
  }
}

function startConfigWatcher(hostConfig = {}) {
  if (configWatcher) return;

  configWatcher = chokidar.watch(CONFIG_PATH, {
    ignoreInitial: true,
    awaitWriteFinish: {
      stabilityThreshold: 250,
      pollInterval: 50,
    },
  });

  const reload = () => {
    try {
      const bridgeConfig = migrateBridgeConfig();
      applyBridgeRuntimeConfig(bridgeConfig, hostConfig, false);
    } catch (error) {
      console.error(
        "[VCPBridgeServer] Failed to hot reload bridge-config.json:",
        error
      );
    }
  };

  configWatcher.on("add", reload);
  configWatcher.on("change", reload);
  configWatcher.on("error", (error) => {
    console.error("[VCPBridgeServer] bridge-config.json watcher error:", error);
  });
}

function shutdown() {
  if (configWatcher) {
    configWatcher.close();
    configWatcher = null;
  }
  if (profilesWatcher) {
    profilesWatcher.close();
    profilesWatcher = null;
  }
  if (server) {
    server.close();
    server = null;
    console.log("[VCPBridgeServer] Server stopped.");
  }
  if (
    bridgeOwnedRagProcessor &&
    typeof bridgeOwnedRagProcessor.shutdown === "function"
  ) {
    bridgeOwnedRagProcessor.shutdown();
  }
  bridgeOwnedRagProcessor = null;
  bridgeRagInitialization = null;
  hostDependencies = {};
}

// ============================================================
// 工具函数
// ============================================================

function normalizeApiType(value) {
  const v = String(value || "")
    .trim()
    .toLowerCase();
  if (v === "anthropic" || v === "claude") return "anthropic";
  if (v === "gemini" || v === "google") return "gemini";
  return "chat";
}

function resolveSystemPrompt(raw) {
  return readSystemPrompt(raw);
}

function readConfiguredPreprocessorOrder() {
  try {
    const parsed = JSON.parse(fs.readFileSync(PREPROCESSOR_ORDER_PATH, "utf8"));
    return Array.isArray(parsed)
      ? parsed.filter((name) => typeof name === "string")
      : [];
  } catch (error) {
    throw new BridgeNativePromptError(
      "preprocessor_order_unavailable",
      `VCP preprocessor order is unavailable: ${error.message}`,
      500
    );
  }
}

function cloneMessages(messages) {
  return JSON.parse(JSON.stringify(Array.isArray(messages) ? messages : []));
}

// Track only placeholders that originate in the injected native Prompt. Content
// introduced later by user text, environment files or RAG recall is ordinary prose,
// even when it quotes placeholder-shaped examples, and must not trigger fail-closed.
function markNativePromptPlaceholders(systemPrompt) {
  const markers = [];
  const nonce = `${Date.now().toString(36)}_${Math.random()
    .toString(36)
    .slice(2)}`;
  let markerIndex = 0;
  const prompt = String(systemPrompt || "").replace(
    NATIVE_PROMPT_PLACEHOLDER,
    (token) => {
      const markerId = `${nonce}_${markerIndex++}`;
      const open = `\uE000VCP_NATIVE_${markerId}_OPEN\uE001`;
      const close = `\uE000VCP_NATIVE_${markerId}_CLOSE\uE001`;
      markers.push({ token, open, close });
      return `${open}${token}${close}`;
    }
  );
  return { prompt, markers };
}

function finalizeNativePromptPlaceholders(messages, markers = []) {
  let residual = null;
  const seenMarkers = new Map(markers.map((marker) => [marker.open, 0]));
  const countOccurrences = (text, needle) =>
    needle ? text.split(needle).length - 1 : 0;
  const stripTrackedMarkers = (value) => {
    let text = String(value || "");
    for (const marker of markers) {
      const openCount = countOccurrences(text, marker.open);
      const closeCount = countOccurrences(text, marker.close);
      if (openCount === 0 && closeCount === 0) continue;
      if (openCount !== 1 || closeCount !== 1) {
        throw new BridgeNativePromptError(
          "native_placeholder_tracking_failed",
          "VCP native placeholder tracking marker was corrupted during preprocessing.",
          500
        );
      }
      const openIndex = text.indexOf(marker.open);
      const contentStart = openIndex + marker.open.length;
      const closeIndex = text.indexOf(marker.close, contentStart);
      if (openIndex < 0 || closeIndex < contentStart) {
        throw new BridgeNativePromptError(
          "native_placeholder_tracking_failed",
          "VCP native placeholder tracking marker was corrupted during preprocessing.",
          500
        );
      }
      const seen = (seenMarkers.get(marker.open) || 0) + 1;
      if (seen !== 1) {
        throw new BridgeNativePromptError(
          "native_placeholder_tracking_failed",
          "VCP native placeholder tracking marker was corrupted during preprocessing.",
          500
        );
      }
      seenMarkers.set(marker.open, seen);
      const replacement = text.slice(contentStart, closeIndex);
      if (replacement === marker.token && !residual) residual = marker.token;
      text =
        text.slice(0, openIndex) +
        replacement +
        text.slice(closeIndex + marker.close.length);
    }
    return text;
  };

  const finalized = cloneMessages(messages).map((message) => {
    if (typeof message?.content === "string") {
      message.content = stripTrackedMarkers(message.content);
    } else if (Array.isArray(message?.content)) {
      for (const part of message.content) {
        if (part?.type === "text" && typeof part.text === "string") {
          part.text = stripTrackedMarkers(part.text);
        }
      }
    }
    return message;
  });
  if (markers.some((marker) => seenMarkers.get(marker.open) !== 1)) {
    throw new BridgeNativePromptError(
      "native_placeholder_tracking_failed",
      "VCP native placeholder tracking marker was corrupted during preprocessing.",
      500
    );
  }
  return { messages: finalized, residual };
}

function findResidualNativePlaceholder(messages, markers = []) {
  return finalizeNativePromptPlaceholders(messages, markers).residual;
}

async function getBridgeRagProcessor() {
  const pluginManager = hostDependencies.pluginManager;
  const injectedProcessor = hostDependencies.ragProcessor;
  if (injectedProcessor?.processMessages) return injectedProcessor;

  const hostProcessor =
    pluginManager?.messagePreprocessors?.get?.("RAGDiaryPlugin");
  if (hostProcessor?.processMessages) return hostProcessor;

  if (!bridgeRagInitialization) {
    bridgeOwnedRagProcessor = require("../RAGDiaryPlugin/RAGDiaryPlugin.js");
    bridgeRagInitialization = Promise.resolve(
      bridgeOwnedRagProcessor.initialize(
        {
          PORT: process.env.PORT,
          Key: process.env.Key,
          PROJECT_BASE_PATH:
            pluginManager?.projectBasePath ||
            path.resolve(__dirname, "..", ".."),
        },
        {
          vectorDBManager: pluginManager?.vectorDBManager,
          tdbKnowledgeManager: pluginManager?.tdbKnowledgeManager,
          vcpLogFunctions: pluginManager?.getVCPLogFunctions?.(),
          pluginManager,
        }
      )
    ).catch((error) => {
      bridgeRagInitialization = null;
      throw error;
    });
  }
  await bridgeRagInitialization;
  return bridgeOwnedRagProcessor;
}

async function executeNativePreprocessor(name, messages, requestConfig = {}) {
  const pluginManager = hostDependencies.pluginManager;
  if (
    name === "RAGDiaryPlugin" &&
    !pluginManager?.messagePreprocessors?.has?.(name)
  ) {
    const ragProcessor = await getBridgeRagProcessor();
    return ragProcessor.processMessages(messages, requestConfig);
  }
  if (!pluginManager?.messagePreprocessors?.has?.(name)) return messages;
  return pluginManager.executeMessagePreprocessor(
    name,
    messages,
    requestConfig
  );
}
async function processBridgeMessages(
  messages,
  model,
  requestConfig = {},
  nativePromptMarkers = []
) {
  const pluginManager = hostDependencies.pluginManager;
  if (!pluginManager) {
    throw new BridgeNativePromptError(
      "native_preprocessor_unavailable",
      "VCP native message processor is unavailable.",
      503
    );
  }

  let processedMessages = cloneMessages(messages);
  if (pluginManager.messagePreprocessors?.has?.("VCPTavern")) {
    processedMessages = await executeNativePreprocessor(
      "VCPTavern",
      processedMessages,
      requestConfig
    );
  }

  const processingContext = {
    pluginManager,
    webSocketServer: hostDependencies.webSocketServer,
    cachedEmojiLists: hostDependencies.cachedEmojiLists || new Map(),
    detectors: hostDependencies.detectors || [],
    superDetectors: hostDependencies.superDetectors || [],
    DEBUG_MODE: runtimeConfig.debugMode === true,
    messages: processedMessages,
    expandedAgentName: null,
    expandedToolboxes: new Set(),
  };

  const variableProcessedMessages = [];
  for (const message of processedMessages) {
    const nextMessage = cloneMessages([message])[0];
    if (typeof nextMessage.content === "string") {
      nextMessage.content = await messageProcessor.replaceAgentVariables(
        nextMessage.content,
        model,
        nextMessage.role,
        processingContext
      );
    } else if (Array.isArray(nextMessage.content)) {
      for (const part of nextMessage.content) {
        if (part?.type === "text" && typeof part.text === "string") {
          part.text = await messageProcessor.replaceAgentVariables(
            part.text,
            model,
            nextMessage.role,
            processingContext
          );
        }
      }
    }
    variableProcessedMessages.push(nextMessage);
  }
  processedMessages = variableProcessedMessages;

  for (const name of readConfiguredPreprocessorOrder()) {
    if (
      name === "VCPTavern" ||
      name === "ImageProcessor" ||
      name === "MultiModalProcessor"
    ) {
      continue;
    }
    processedMessages = await executeNativePreprocessor(
      name,
      processedMessages,
      requestConfig
    );
  }

  processedMessages = messageProcessor.applyDetectorsToMessages(
    processedMessages,
    processingContext
  );

  const finalized = finalizeNativePromptPlaceholders(
    processedMessages,
    nativePromptMarkers
  );
  if (finalized.residual) {
    throw new BridgeNativePromptError(
      "native_placeholder_unresolved",
      `VCP native placeholder could not be expanded: ${finalized.residual}`
    );
  }
  return finalized.messages;
}

function resolveModel(model) {
  const candidate = model || runtimeConfig.defaultModel;
  return runtimeConfig.modelMap[candidate] || candidate;
}

function extractBearerToken(authHeader) {
  if (!authHeader) return "";
  const match = authHeader.match(/^Bearer\s+(.+)$/i);
  return match ? match[1].trim() : "";
}
function sanitizeDiaryAssistantContent(content, fallbackMessage) {
  const text = String(content || "");
  const withoutToolBlocks = text
    .replace(/<<<\[TOOL_REQUEST\]>>>[\s\S]*?<<<\[END_TOOL_REQUEST\]>>>/gi, "")
    .replace(/<<<DailyNoteStart>>>[\s\S]*?<<<DailyNoteEnd>>>/gi, "")
    .trim();
  return withoutToolBlocks || fallbackMessage;
}

function sanitizeDiaryResponsePayload(payload, bookTitle) {
  const message = payload?.choices?.[0]?.message;
  if (message && typeof message === "object") {
    message.content = `《${bookTitle}》的本次共读日记已写入。`;
    delete message.tool_calls;
  }
  return payload;
}
function createFallbackModelsResponse() {
  const ids = new Set(
    [
      runtimeConfig.defaultModel,
      ...Object.values(runtimeConfig.modelMap),
    ].filter(Boolean)
  );
  return {
    object: "list",
    data: Array.from(ids).map((id) => ({
      id,
      object: "model",
      created: 0,
      owned_by: "vcp-bridge",
    })),
  };
}

function copyProxyHeaders(upstreamResponse, res) {
  upstreamResponse.headers.forEach((value, key) => {
    const normalized = key.toLowerCase();
    if (
      ![
        "content-encoding",
        "transfer-encoding",
        "connection",
        "content-length",
        "keep-alive",
      ].includes(normalized)
    ) {
      res.setHeader(key, value);
    }
  });
}

// ============================================================
// 原生工具字段保护/转换（不进入 messages，只在构建上游 body 时加回）
// ============================================================

function normalizeToolParameters(parameters) {
  if (parameters && typeof parameters === "object") return parameters;
  return { type: "object", properties: {} };
}

function toOpenAiChatTool(tool) {
  if (!tool || typeof tool !== "object") return null;

  if (tool.type === "function" && tool.function?.name) {
    return {
      type: "function",
      function: {
        name: tool.function.name,
        ...(tool.function.description && {
          description: tool.function.description,
        }),
        parameters: normalizeToolParameters(
          tool.function.parameters || tool.function.input_schema
        ),
      },
    };
  }

  if ((tool.type === "function" || !tool.type) && tool.name) {
    return {
      type: "function",
      function: {
        name: tool.name,
        ...(tool.description && { description: tool.description }),
        parameters: normalizeToolParameters(
          tool.parameters || tool.input_schema || tool.schema
        ),
      },
    };
  }

  return null;
}

function extractProtectedTools(body) {
  const tools = [];

  if (Array.isArray(body?.tools)) {
    for (const tool of body.tools) {
      const functionDeclarations =
        tool?.functionDeclarations || tool?.function_declarations;
      if (Array.isArray(functionDeclarations)) {
        for (const declaration of functionDeclarations) {
          const converted = toOpenAiChatTool(declaration);
          if (converted) tools.push(converted);
        }
        continue;
      }

      const converted = toOpenAiChatTool(tool);
      if (converted) tools.push(converted);
    }
  }

  if (Array.isArray(body?.functions)) {
    for (const fn of body.functions) {
      const converted = toOpenAiChatTool({ type: "function", ...fn });
      if (converted) tools.push(converted);
    }
  }

  return tools;
}

function normalizeToolChoice(toolChoice, body) {
  if (!toolChoice && body?.toolConfig?.functionCallingConfig) {
    const config = body.toolConfig.functionCallingConfig;
    const mode = String(config.mode || "").toUpperCase();
    if (mode === "NONE") return "none";
    if (mode === "ANY") {
      const allowed = Array.isArray(config.allowedFunctionNames)
        ? config.allowedFunctionNames.filter(Boolean)
        : [];
      if (allowed.length === 1) {
        return { type: "function", function: { name: allowed[0] } };
      }
      return "required";
    }
    if (mode === "AUTO") return "auto";
  }

  if (!toolChoice) return undefined;
  if (typeof toolChoice === "string") return toolChoice;
  if (typeof toolChoice !== "object") return undefined;

  if (toolChoice.type === "function" && toolChoice.function?.name) {
    return { type: "function", function: { name: toolChoice.function.name } };
  }

  if (toolChoice.type === "function" && toolChoice.name) {
    return { type: "function", function: { name: toolChoice.name } };
  }

  if (toolChoice.type === "tool" && toolChoice.name) {
    return { type: "function", function: { name: toolChoice.name } };
  }

  if (toolChoice.type === "auto") return "auto";
  if (toolChoice.type === "any") return "required";
  if (toolChoice.type === "none") return "none";

  return undefined;
}

function attachProtectedChatToolFields(targetBody, sourceBody) {
  const tools = extractProtectedTools(sourceBody);
  if (tools.length > 0) targetBody.tools = tools;

  const toolChoice = normalizeToolChoice(sourceBody?.tool_choice, sourceBody);
  if (toolChoice !== undefined) targetBody.tool_choice = toolChoice;

  if (typeof sourceBody?.parallel_tool_calls === "boolean") {
    targetBody.parallel_tool_calls = sourceBody.parallel_tool_calls;
  }

  return targetBody;
}

function attachProtectedAnthropicToolFields(targetBody, sourceBody) {
  const tools = extractProtectedTools(sourceBody).map((tool) => ({
    name: tool.function.name,
    ...(tool.function.description && {
      description: tool.function.description,
    }),
    input_schema: normalizeToolParameters(tool.function.parameters),
  }));

  if (tools.length > 0) targetBody.tools = tools;
  if (sourceBody?.tool_choice) targetBody.tool_choice = sourceBody.tool_choice;

  return targetBody;
}

function attachProtectedGeminiToolFields(targetBody, sourceBody) {
  const functionDeclarations = extractProtectedTools(sourceBody).map(
    (tool) => ({
      name: tool.function.name,
      ...(tool.function.description && {
        description: tool.function.description,
      }),
      parameters: normalizeToolParameters(tool.function.parameters),
    })
  );

  if (functionDeclarations.length > 0) {
    targetBody.tools = [{ functionDeclarations }];
  }

  if (sourceBody?.toolConfig) {
    targetBody.toolConfig = sourceBody.toolConfig;
  }

  return targetBody;
}

// ============================================================
// Responses API 响应转换工具
// ============================================================

function buildResponsesUsage(usage) {
  return {
    input_tokens: usage?.prompt_tokens || usage?.input_tokens || 0,
    output_tokens: usage?.completion_tokens || usage?.output_tokens || 0,
    total_tokens:
      usage?.total_tokens ||
      (usage?.input_tokens || 0) + (usage?.output_tokens || 0),
    input_tokens_details:
      usage?.prompt_tokens_details || usage?.input_tokens_details || {},
    output_tokens_details:
      usage?.completion_tokens_details || usage?.output_tokens_details || {},
  };
}

function buildBaseResponsesEnvelope(model) {
  return {
    id: `resp_${Date.now()}`,
    object: "response",
    created_at: Math.floor(Date.now() / 1000),
    status: "in_progress",
    model,
    output: [
      {
        id: `msg_${Date.now()}`,
        type: "message",
        role: "assistant",
        content: [{ type: "output_text", text: "", annotations: [] }],
      },
    ],
    output_text: "",
    usage: buildResponsesUsage(null),
  };
}

function writeResponsesSseEvent(res, eventName, data) {
  if (res.destroyed || res.writableEnded) return false;
  res.write(`event: ${eventName}\n`);
  res.write(`data: ${JSON.stringify(data)}\n\n`);
  return true;
}

function safeJsonParse(text) {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function extractProtocolErrorMessage(rawText) {
  const rawJson = safeJsonParse(rawText);
  if (rawJson?.error?.message) return rawJson.error.message;
  if (rawJson?.message) return rawJson.message;
  return String(rawText || "").trim();
}

function detectVcpUpstreamErrorTranscript(text) {
  const normalized = String(text || "").trim();
  if (!normalized) return null;

  if (normalized.startsWith("[UPSTREAM_ERROR]")) {
    return {
      code: "vcp_upstream_error",
      message: normalized,
    };
  }

  if (normalized.startsWith("[ERROR] 代理服务器在连接上游API时失败")) {
    return {
      code: "vcp_upstream_error",
      message: normalized,
    };
  }

  return null;
}

function writeResponsesFailure(res, responsePayload, errorInfo) {
  responsePayload.status = "failed";
  responsePayload.output_text = "";
  if (responsePayload.output?.[0]?.content?.[0]) {
    responsePayload.output[0].content[0].text = "";
  }
  responsePayload.error = {
    code: errorInfo.code || "vcp_bridge_upstream_error",
    message: errorInfo.message || "VCP bridge upstream request failed.",
  };
  writeResponsesSseEvent(res, "response.failed", {
    type: "response.failed",
    response: responsePayload,
  });
}

function extractTextFromProtocolResponse(raw, apiType) {
  if (apiType === "anthropic") {
    const content = raw?.content;
    return Array.isArray(content)
      ? content.map((item) => item?.text || "").join("")
      : "";
  }
  if (apiType === "gemini") {
    const parts = raw?.candidates?.[0]?.content?.parts;
    return Array.isArray(parts)
      ? parts.map((part) => part?.text || "").join("")
      : "";
  }
  return raw?.choices?.[0]?.message?.content || "";
}

function extractUsageFromProtocolResponse(raw, apiType) {
  if (apiType === "anthropic") {
    return {
      input_tokens: raw?.usage?.input_tokens || 0,
      output_tokens: raw?.usage?.output_tokens || 0,
      total_tokens:
        (raw?.usage?.input_tokens || 0) + (raw?.usage?.output_tokens || 0),
    };
  }
  if (apiType === "gemini") {
    return {
      prompt_tokens: raw?.usageMetadata?.promptTokenCount || 0,
      completion_tokens: raw?.usageMetadata?.candidatesTokenCount || 0,
      total_tokens: raw?.usageMetadata?.totalTokenCount || 0,
    };
  }
  return raw?.usage || null;
}

function extractStreamDeltaByProtocol(eventJson, apiType) {
  if (apiType === "anthropic") {
    return eventJson?.delta?.text || eventJson?.content_block?.text || "";
  }
  if (apiType === "gemini") {
    const parts = eventJson?.candidates?.[0]?.content?.parts;
    return Array.isArray(parts)
      ? parts.map((part) => part?.text || "").join("")
      : "";
  }
  return (
    eventJson?.choices?.[0]?.delta?.content ||
    eventJson?.choices?.[0]?.message?.content ||
    ""
  );
}

function extractStreamUsageByProtocol(eventJson, apiType) {
  if (apiType === "gemini" && eventJson?.usageMetadata) {
    return {
      prompt_tokens: eventJson.usageMetadata.promptTokenCount || 0,
      completion_tokens: eventJson.usageMetadata.candidatesTokenCount || 0,
      total_tokens: eventJson.usageMetadata.totalTokenCount || 0,
    };
  }
  return eventJson?.usage || null;
}

function getChatStreamToolCallDelta(eventJson) {
  const toolCalls = eventJson?.choices?.[0]?.delta?.tool_calls;
  return Array.isArray(toolCalls) ? toolCalls : [];
}

async function* iterateUpstreamSseJson(readableStream) {
  const decoder = new TextDecoder("utf-8");
  let buffer = "";

  for await (const chunk of readableStream) {
    buffer += decoder.decode(chunk, { stream: true });

    while (true) {
      const newlineIndex = buffer.indexOf("\n");
      if (newlineIndex === -1) break;

      const line = buffer.slice(0, newlineIndex).trimEnd();
      buffer = buffer.slice(newlineIndex + 1);

      const trimmed = line.trim();
      if (!trimmed || !trimmed.startsWith("data:")) continue;

      const data = trimmed.slice(5).trim();
      if (data === "[DONE]") return;

      const json = safeJsonParse(data);
      if (json) yield json;
    }
  }
}

function buildResponsesOutput(raw, apiType, fallbackModel) {
  const text = extractTextFromProtocolResponse(raw, apiType);
  const responsePayload = buildBaseResponsesEnvelope(
    raw?.model || fallbackModel
  );
  const toolCalls =
    apiType === "chat" && Array.isArray(raw?.choices?.[0]?.message?.tool_calls)
      ? raw.choices[0].message.tool_calls
      : [];
  responsePayload.status = "completed";
  if (toolCalls.length > 0 && !text) {
    responsePayload.output = toolCalls.map((toolCall) => ({
      id: toolCall.id || `fc_${Date.now()}`,
      type: "function_call",
      call_id: toolCall.id || `call_${Date.now()}`,
      name: toolCall.function?.name || "",
      arguments: toolCall.function?.arguments || "",
    }));
  } else {
    responsePayload.output[0].content[0].text = text;
  }
  responsePayload.output_text = text;
  responsePayload.usage = buildResponsesUsage(
    extractUsageFromProtocolResponse(raw, apiType)
  );
  return responsePayload;
}

async function sendResponsesStreamFromProtocol(
  res,
  upstreamResponse,
  { model, apiType }
) {
  const upstreamOk =
    typeof upstreamResponse.ok === "boolean"
      ? upstreamResponse.ok
      : upstreamResponse.status >= 200 && upstreamResponse.status < 300;
  res.status(upstreamOk ? upstreamResponse.status : 200);
  res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");

  const responsePayload = buildBaseResponsesEnvelope(model);
  const itemId = responsePayload.output[0].id;
  let finalUsage = null;
  const toolCallBuffers = new Map();
  let messageStarted = false;
  let terminalFailure = null;

  writeResponsesSseEvent(res, "response.created", {
    type: "response.created",
    response: {
      id: responsePayload.id,
      object: responsePayload.object,
      created_at: responsePayload.created_at,
      status: "in_progress",
      model: responsePayload.model,
      usage: buildResponsesUsage(null),
    },
  });

  try {
    if (!upstreamOk) {
      const rawText = await upstreamResponse.text();
      writeResponsesFailure(res, responsePayload, {
        code: "vcp_upstream_error",
        message: `上游 API 返回状态码 ${
          upstreamResponse.status
        }: ${extractProtocolErrorMessage(rawText)}`,
      });
      if (!res.destroyed && !res.writableEnded) res.end();
      return;
    }

    for await (const eventJson of iterateUpstreamSseJson(
      upstreamResponse.body
    )) {
      for (const toolDelta of getChatStreamToolCallDelta(eventJson)) {
        const outputIndex =
          typeof toolDelta.index === "number"
            ? toolDelta.index
            : toolCallBuffers.size;
        const id = toolDelta.id || `call_${outputIndex}`;
        const existing = toolCallBuffers.get(outputIndex) || {
          id,
          call_id: id,
          name: "",
          arguments: "",
          emitted: false,
        };

        if (toolDelta.id) {
          existing.id = toolDelta.id;
          existing.call_id = toolDelta.id;
        }
        if (toolDelta.function?.name) existing.name += toolDelta.function.name;
        if (toolDelta.function?.arguments)
          existing.arguments += toolDelta.function.arguments;
        toolCallBuffers.set(outputIndex, existing);

        if (!existing.emitted) {
          existing.emitted = true;
          writeResponsesSseEvent(res, "response.output_item.added", {
            type: "response.output_item.added",
            output_index: outputIndex,
            item: {
              id: existing.id,
              type: "function_call",
              call_id: existing.call_id,
              name: existing.name,
              arguments: "",
            },
          });
        }

        if (toolDelta.function?.arguments) {
          writeResponsesSseEvent(
            res,
            "response.function_call_arguments.delta",
            {
              type: "response.function_call_arguments.delta",
              item_id: existing.id,
              output_index: outputIndex,
              delta: toolDelta.function.arguments,
            }
          );
        }
      }

      const delta = extractStreamDeltaByProtocol(eventJson, apiType);
      if (typeof delta === "string" && delta.length > 0) {
        const vcpUpstreamError = detectVcpUpstreamErrorTranscript(
          responsePayload.output_text + delta
        );
        if (vcpUpstreamError) {
          terminalFailure = vcpUpstreamError;
          break;
        }

        if (!messageStarted) {
          messageStarted = true;
          writeResponsesSseEvent(res, "response.output_item.added", {
            type: "response.output_item.added",
            output_index: 0,
            item: {
              id: itemId,
              type: "message",
              role: "assistant",
              content: [],
            },
          });

          writeResponsesSseEvent(res, "response.content_part.added", {
            type: "response.content_part.added",
            item_id: itemId,
            output_index: 0,
            content_index: 0,
            part: { type: "output_text", text: "" },
          });
        }
        responsePayload.output_text += delta;
        writeResponsesSseEvent(res, "response.output_text.delta", {
          type: "response.output_text.delta",
          item_id: itemId,
          output_index: 0,
          content_index: 0,
          delta,
        });
      }

      const usage = extractStreamUsageByProtocol(eventJson, apiType);
      if (usage) finalUsage = usage;
      if (eventJson?.model) responsePayload.model = eventJson.model;
    }

    if (terminalFailure) {
      writeResponsesFailure(res, responsePayload, terminalFailure);
      if (!res.destroyed && !res.writableEnded) res.end();
      return;
    }

    if (toolCallBuffers.size === 0 && !responsePayload.output_text) {
      writeResponsesFailure(res, responsePayload, {
        code: "empty_upstream_response",
        message:
          "上游模型返回了空响应，且没有工具调用。Snow 需要把这一轮视为失败/可重试，而不是已完成。",
      });
      if (!res.destroyed && !res.writableEnded) res.end();
      return;
    }

    responsePayload.status = "completed";
    if (toolCallBuffers.size > 0 && !responsePayload.output_text) {
      responsePayload.output = Array.from(toolCallBuffers.entries())
        .sort(([leftIndex], [rightIndex]) => leftIndex - rightIndex)
        .map(([outputIndex, toolCall]) => {
          const item = {
            id: toolCall.id,
            type: "function_call",
            call_id: toolCall.call_id,
            name: toolCall.name,
            arguments: toolCall.arguments,
          };

          writeResponsesSseEvent(res, "response.function_call_arguments.done", {
            type: "response.function_call_arguments.done",
            item_id: toolCall.id,
            output_index: outputIndex,
            arguments: toolCall.arguments,
          });

          writeResponsesSseEvent(res, "response.output_item.done", {
            type: "response.output_item.done",
            output_index: outputIndex,
            item,
          });

          return item;
        });
    } else {
      if (!messageStarted) {
        writeResponsesSseEvent(res, "response.output_item.added", {
          type: "response.output_item.added",
          output_index: 0,
          item: { id: itemId, type: "message", role: "assistant", content: [] },
        });

        writeResponsesSseEvent(res, "response.content_part.added", {
          type: "response.content_part.added",
          item_id: itemId,
          output_index: 0,
          content_index: 0,
          part: { type: "output_text", text: "" },
        });
      }
      responsePayload.output[0].content[0].text = responsePayload.output_text;
    }
    if (finalUsage) responsePayload.usage = buildResponsesUsage(finalUsage);

    if (!(toolCallBuffers.size > 0 && !responsePayload.output_text)) {
      writeResponsesSseEvent(res, "response.output_text.done", {
        type: "response.output_text.done",
        item_id: itemId,
        output_index: 0,
        content_index: 0,
        text: responsePayload.output_text,
      });

      writeResponsesSseEvent(res, "response.content_part.done", {
        type: "response.content_part.done",
        item_id: itemId,
        output_index: 0,
        content_index: 0,
        part: { type: "output_text", text: responsePayload.output_text },
      });

      writeResponsesSseEvent(res, "response.output_item.done", {
        type: "response.output_item.done",
        output_index: 0,
        item: responsePayload.output[0],
      });
    }

    writeResponsesSseEvent(res, "response.completed", {
      type: "response.completed",
      response: responsePayload,
    });
  } catch (error) {
    responsePayload.output[0].content[0].text = responsePayload.output_text;
    writeResponsesFailure(res, responsePayload, {
      code: "vcp_bridge_stream_error",
      message: error.message || "VCP bridge stream failed before completion.",
    });
  }

  if (!res.destroyed && !res.writableEnded) res.end();
}

async function sendResponsesJsonFromProtocol(
  res,
  upstreamResponse,
  { model, apiType }
) {
  const rawText = await upstreamResponse.text();
  const rawJson = safeJsonParse(rawText);

  if (!upstreamResponse.ok) {
    return res
      .status(upstreamResponse.status)
      .type("application/json")
      .send(rawJson || rawText);
  }

  return res
    .status(upstreamResponse.status)
    .json(buildResponsesOutput(rawJson || {}, apiType, model));
}

// ============================================================
// Profile 缓存管理
// ============================================================

function loadAllProfiles() {
  try {
    const nextCache = new Map();
    const profiles = listProfiles();
    for (const profile of profiles) {
      if (profile.systemPrompt) resolveSystemPrompt(profile.systemPrompt);
      nextCache.set(profile.name, profile);
    }
    profilesCache = nextCache;
    if (runtimeConfig.debugMode) {
      console.log(
        `[VCPBridgeServer] Profiles cache reloaded: ${profilesCache.size} profiles.`
      );
    }
  } catch (error) {
    console.error(
      "[VCPBridgeServer] Failed to load profiles; keeping previous cache:",
      error.message
    );
  }
}

function readProfileCached(name) {
  if (!name) return null;
  const canonicalName = String(name);
  // Read through on every request so create/update/delete operations are observable
  // immediately. The watcher-backed cache remains useful for startup validation and
  // diagnostics, but never serves stale Profile data.
  const profile = readProfile(canonicalName);
  if (profile) profilesCache.set(canonicalName, profile);
  else profilesCache.delete(canonicalName);
  return profile;
}

function attachProfileModelPrefix(profile, model) {
  if (!profile || typeof model !== "string") return profile;
  const prefix = `${profile.name}/`;
  if (!model.startsWith(prefix) || model.length === prefix.length)
    return profile;
  return { ...profile, _extractedModel: model.slice(prefix.length) };
}

/**
 * 解析当前请求应该使用的 Profile 配置
 * 优先级：URL path > HTTP header > model name prefix > defaultProfile > null
 */
function resolveProfileForRequest(req, model) {
  if (req.bridgeProfile) {
    const profile = readProfileCached(req.bridgeProfile);
    if (profile) return attachProfileModelPrefix(profile, model);
    throw new BridgePromptError(
      "profile_not_found",
      "Requested Bridge Profile does not exist.",
      404
    );
  }

  const headerProfile = req.headers["x-bridge-profile"];
  if (headerProfile) {
    const profile = readProfileCached(headerProfile);
    if (profile) return attachProfileModelPrefix(profile, model);
    throw new BridgePromptError(
      "profile_not_found",
      "Requested Bridge Profile does not exist.",
      404
    );
  }

  if (model && model.includes("/")) {
    const slashIdx = model.indexOf("/");
    const maybeProfile = model.slice(0, slashIdx);
    const cachedProfile = readProfileCached(maybeProfile);
    if (cachedProfile) {
      return { ...cachedProfile, _extractedModel: model.slice(slashIdx + 1) };
    }
  }

  if (runtimeConfig.defaultProfile) {
    const profile = readProfileCached(runtimeConfig.defaultProfile);
    if (profile) return profile;
  }

  return null;
}

// ============================================================
// System Prompt 劫持逻辑（带参数版本）
// ============================================================

function applySystemPromptHijackWithConfig(messages, systemPrompt, hijackMode) {
  if (!systemPrompt || hijackMode === "off") {
    return messages;
  }

  const result = [...messages];
  const injected = { role: "system", content: systemPrompt };

  switch (hijackMode) {
    case "replace":
      const nonSystem = result.filter((m) => m.role !== "system");
      return [injected, ...nonSystem];

    case "prepend":
      return [injected, ...result];

    case "append": {
      const lastSystemIdx = result.reduce(
        (acc, m, i) => (m.role === "system" ? i : acc),
        -1
      );
      if (lastSystemIdx >= 0) {
        result.splice(lastSystemIdx + 1, 0, injected);
      } else {
        result.unshift(injected);
      }
      return result;
    }

    case "merge": {
      const systemContents = [
        injected.content,
        ...result
          .filter((m) => m.role === "system")
          .map((m) => m.content)
          .filter((content) => typeof content === "string" && content.trim()),
      ];
      const mergedSystem = {
        role: "system",
        content: systemContents.join("\n\n"),
      };
      const nonSys = result.filter((m) => m.role !== "system");
      return [mergedSystem, ...nonSys];
    }

    default:
      return result;
  }
}

// ============================================================
// System Prompt 劫持逻辑
// ============================================================

function applySystemPromptHijack(messages) {
  if (!runtimeConfig.systemPrompt || runtimeConfig.hijackMode === "off") {
    return messages;
  }

  const result = [...messages];
  const injected = { role: "system", content: runtimeConfig.systemPrompt };

  switch (runtimeConfig.hijackMode) {
    case "replace":
      // 移除所有 system 消息，替换为我们的
      const nonSystem = result.filter((m) => m.role !== "system");
      return [injected, ...nonSystem];

    case "prepend":
      // 在第一条 system 消息之前插入
      return [injected, ...result];

    case "append": {
      // 在最后一条 system 消息之后插入
      const lastSystemIdx = result.reduce(
        (acc, m, i) => (m.role === "system" ? i : acc),
        -1
      );
      if (lastSystemIdx >= 0) {
        result.splice(lastSystemIdx + 1, 0, injected);
      } else {
        result.unshift(injected);
      }
      return result;
    }

    case "merge": {
      // 合并所有 system 消息为一条置顶 system；注入提示词优先，然后按原消息顺序拼接已有 system。
      const systemContents = [
        injected.content,
        ...result
          .filter((m) => m.role === "system")
          .map((m) => m.content)
          .filter((content) => typeof content === "string" && content.trim()),
      ];
      const mergedSystem = {
        role: "system",
        content: systemContents.join("\n\n"),
      };
      const nonSystem = result.filter((m) => m.role !== "system");
      return [mergedSystem, ...nonSystem];
    }

    default:
      return result;
  }
}

// ============================================================
// 消息提取（各协议 → 统一 messages 数组）
// ============================================================

function normalizeTextContent(content) {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content
      .map((item) => {
        if (typeof item === "string") return item;
        if (item?.type === "text" && typeof item.text === "string")
          return item.text;
        if (item?.type === "input_text" && typeof item.text === "string")
          return item.text;
        if (item?.type === "output_text" && typeof item.text === "string")
          return item.text;
        return "";
      })
      .filter(Boolean)
      .join("\n");
  }
  return "";
}

function normalizeResponsesToolOutput(item) {
  const output = item.output ?? item.content;
  if (typeof output === "string") return output;
  if (output === undefined || output === null) return "";

  const text = normalizeTextContent(output);
  if (text) return text;

  try {
    return JSON.stringify(output);
  } catch {
    return String(output);
  }
}

function formatResponsesToolCall(item) {
  if (!item || typeof item !== "object") return null;

  if (item.type === "function_call") {
    const id = item.call_id || item.id;
    if (!id || !item.name) return null;
    const args =
      typeof item.arguments === "string"
        ? item.arguments
        : JSON.stringify(item.arguments || {});
    return `- call_id: ${id}\n  name: ${item.name}\n  arguments: ${args}`;
  }

  if (item.type === "function" && item.name) {
    const id = item.call_id || item.id;
    if (!id) return null;
    const args =
      typeof item.arguments === "string"
        ? item.arguments
        : JSON.stringify(item.arguments || {});
    return `- call_id: ${id}\n  name: ${item.name}\n  arguments: ${args}`;
  }

  return null;
}

function formatResponsesToolOutput(item, toolCallNamesById) {
  if (!item || typeof item !== "object") return null;
  const toolCallId = item.call_id || item.tool_call_id || item.id;
  const content = normalizeResponsesToolOutput(item);
  if (!toolCallId || !content) return null;
  const name = item.name || toolCallNamesById.get(toolCallId) || "";
  return `- call_id: ${toolCallId}${
    name ? `\n  name: ${name}` : ""
  }\n  output: ${content}`;
}

function extractFromResponsesInput(input) {
  if (typeof input === "string") return [{ role: "user", content: input }];
  if (!Array.isArray(input)) return [];
  const messages = [];
  let pendingAssistantContent = null;
  let pendingToolCallTranscripts = [];
  let pendingToolOutputTranscripts = [];
  const toolCallNamesById = new Map();

  const flushPendingAssistantContent = () => {
    if (!pendingAssistantContent && pendingToolCallTranscripts.length === 0)
      return;
    const parts = [];
    if (pendingAssistantContent) parts.push(pendingAssistantContent);
    if (pendingToolCallTranscripts.length > 0) {
      parts.push(`历史工具调用:\n${pendingToolCallTranscripts.join("\n")}`);
    }
    messages.push({ role: "assistant", content: parts.join("\n\n") });
    pendingAssistantContent = null;
    pendingToolCallTranscripts = [];
  };

  const flushPendingToolOutputs = () => {
    if (pendingToolOutputTranscripts.length === 0) return;
    messages.push({
      role: "user",
      content: [
        `历史工具结果:\n${pendingToolOutputTranscripts.join("\n")}`,
        "请基于以上工具结果继续完成上一轮用户任务。如果任务已经完成，请明确给出完成状态和简短结果，不要只停在工具结果本身。",
      ].join("\n\n"),
    });
    pendingToolOutputTranscripts = [];
  };

  for (const item of input) {
    if (!item || typeof item !== "object") continue;

    if (Array.isArray(item.tool_calls) && item.tool_calls.length > 0) {
      flushPendingToolOutputs();
      const content = normalizeTextContent(item.content || item.output);
      if (content) {
        if (pendingAssistantContent) flushPendingAssistantContent();
        pendingAssistantContent = content;
      }
      for (const toolCall of item.tool_calls) {
        const id = toolCall?.id;
        const name = toolCall?.function?.name;
        if (id && name) toolCallNamesById.set(id, name);
        if (id || name) {
          pendingToolCallTranscripts.push(
            `- call_id: ${id || ""}\n  name: ${name || ""}\n  arguments: ${
              toolCall?.function?.arguments || ""
            }`
          );
        }
      }
      continue;
    }

    const toolCallTranscript = formatResponsesToolCall(item);
    if (toolCallTranscript) {
      const id = item.call_id || item.id;
      if (id && item.name) toolCallNamesById.set(id, item.name);
      flushPendingToolOutputs();
      pendingToolCallTranscripts.push(toolCallTranscript);
      continue;
    }

    if (item.type === "function_call_output" || item.role === "tool") {
      flushPendingAssistantContent();
      const transcript = formatResponsesToolOutput(item, toolCallNamesById);
      if (transcript) pendingToolOutputTranscripts.push(transcript);
      continue;
    }

    flushPendingAssistantContent();
    flushPendingToolOutputs();
    let role = item.role || (item.type === "message" ? "user" : null);
    if (role === "developer") role = "system";
    const content = normalizeTextContent(item.content || item.output);
    if (role === "assistant" && content) {
      if (pendingAssistantContent) flushPendingAssistantContent();
      pendingAssistantContent = content;
      continue;
    }
    flushPendingAssistantContent();
    if (role && content) messages.push({ role, content });
  }
  flushPendingAssistantContent();
  flushPendingToolOutputs();
  return messages;
}

function extractFromAnthropicBody(body) {
  const messages = [];
  // system
  if (body.system) {
    const sys =
      typeof body.system === "string"
        ? body.system
        : Array.isArray(body.system)
        ? body.system
            .map((i) => i?.text || "")
            .filter(Boolean)
            .join("\n")
        : "";
    if (sys) messages.push({ role: "system", content: sys });
  }
  // messages
  if (Array.isArray(body.messages)) {
    for (const m of body.messages) {
      const content = normalizeTextContent(m.content);
      if (m.role && content) messages.push({ role: m.role, content });
    }
  }
  return messages;
}

function extractFromGeminiBody(body) {
  const messages = [];
  // systemInstruction
  if (body.systemInstruction?.parts) {
    const sys = body.systemInstruction.parts
      .map((p) => p?.text || "")
      .filter(Boolean)
      .join("\n");
    if (sys) messages.push({ role: "system", content: sys });
  }
  // contents
  if (Array.isArray(body.contents)) {
    for (const c of body.contents) {
      const role = c.role === "model" ? "assistant" : "user";
      const text = normalizeTextContent(c.parts);
      if (text) messages.push({ role, content: text });
    }
  }
  return messages;
}

// ============================================================
// 上游请求构建（统一 messages → 目标协议格式）
// ============================================================

function buildUpstreamChatBody(messages, model, body) {
  const result = {
    model: resolveModel(model),
    messages,
    stream: body.stream === true,
    ...(body.temperature !== undefined && { temperature: body.temperature }),
    ...(body.top_p !== undefined && { top_p: body.top_p }),
    ...(body.max_tokens !== undefined || body.max_output_tokens !== undefined
      ? { max_tokens: body.max_output_tokens || body.max_tokens }
      : {}),
  };
  return attachProtectedChatToolFields(result, body);
}

function buildUpstreamAnthropicBody(messages, model, body) {
  const system = messages
    .filter((m) => m.role === "system")
    .map((m) => m.content)
    .join("\n\n");
  const nonSystem = messages
    .filter((m) => m.role !== "system")
    .map((m) => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: m.content,
    }));
  const result = {
    model: resolveModel(model),
    messages: nonSystem,
    max_tokens: body.max_tokens || body.max_output_tokens || 4096,
    stream: body.stream === true,
  };
  if (system) result.system = system;
  if (body.temperature !== undefined) result.temperature = body.temperature;
  return attachProtectedAnthropicToolFields(result, body);
}

function buildUpstreamGeminiBody(messages, model, body) {
  const system = messages
    .filter((m) => m.role === "system")
    .map((m) => m.content)
    .join("\n\n");
  const contents = messages
    .filter((m) => m.role !== "system")
    .map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }],
    }));
  const result = { contents };
  if (system) result.systemInstruction = { parts: [{ text: system }] };
  const genConfig = {};
  if (body.temperature !== undefined) genConfig.temperature = body.temperature;
  if (body.top_p !== undefined) genConfig.topP = body.top_p;
  if (body.max_tokens !== undefined || body.max_output_tokens !== undefined) {
    genConfig.maxOutputTokens = body.max_output_tokens || body.max_tokens;
  }
  if (Object.keys(genConfig).length > 0) result.generationConfig = genConfig;
  return attachProtectedGeminiToolFields(result, body);
}

// ============================================================
// 上游路由解析
// ============================================================

function resolveUpstreamEndpoint(model, stream) {
  const type = runtimeConfig.upstreamType;
  const base = runtimeConfig.upstreamUrl;

  if (type === "anthropic") {
    return { url: `${base}/v1/messages`, type: "anthropic" };
  }
  if (type === "gemini") {
    const m = encodeURIComponent(resolveModel(model));
    const action = stream ? "streamGenerateContent" : "generateContent";
    return { url: `${base}/v1beta/models/${m}:${action}`, type: "gemini" };
  }
  return { url: `${base}/v1/chat/completions`, type: "chat" };
}

// ============================================================
// 核心代理逻辑
// ============================================================

async function proxyRequest(
  req,
  res,
  { messages, model, body, downstreamFormat }
) {
  // 0. 解析 Profile（请求级动态切换）
  let profileConfig;
  try {
    profileConfig = resolveProfileForRequest(req, model);
  } catch (error) {
    if (!(error instanceof BridgePromptError)) throw error;
    return res.status(error.statusCode || 422).json({
      error: {
        message: error.message,
        type: error.code || "invalid_bridge_profile",
      },
    });
  }

  // 如果 profile 通过 model 前缀提取了真实 model，使用它
  const effectiveModel = profileConfig?._extractedModel || model;

  // 1. 应用 system prompt 劫持（使用 profile 配置或全局兜底）
  let hijackedMessages;
  let nativePromptMarkers = [];
  if (profileConfig && profileConfig.systemPrompt) {
    let resolvedPrompt;
    try {
      resolvedPrompt = resolveSystemPrompt(profileConfig.systemPrompt);
    } catch (error) {
      if (!(error instanceof BridgePromptError)) throw error;
      return res.status(error.statusCode || 422).json({
        error: {
          message: error.message,
          type: error.code || "invalid_profile_prompt",
        },
      });
    }
    const resolvedMode = profileConfig.hijackMode || runtimeConfig.hijackMode;
    const trackedPrompt =
      resolvedMode === "off"
        ? { prompt: resolvedPrompt, markers: [] }
        : markNativePromptPlaceholders(resolvedPrompt);
    nativePromptMarkers = trackedPrompt.markers;
    hijackedMessages = applySystemPromptHijackWithConfig(
      messages,
      trackedPrompt.prompt,
      resolvedMode
    );
    if (runtimeConfig.debugMode) {
      console.log(
        `[VCPBridgeServer] Using profile "${
          profileConfig.name
        }" | mode=${resolvedMode} | prompt=${profileConfig.systemPrompt.substring(
          0,
          40
        )}...`
      );
    }
  } else {
    const trackedPrompt =
      runtimeConfig.hijackMode === "off"
        ? { prompt: runtimeConfig.systemPrompt, markers: [] }
        : markNativePromptPlaceholders(runtimeConfig.systemPrompt);
    nativePromptMarkers = trackedPrompt.markers;
    hijackedMessages = applySystemPromptHijackWithConfig(
      messages,
      trackedPrompt.prompt,
      runtimeConfig.hijackMode
    );
  }

  // 如果 profile 有 modelOverride，优先使用
  const finalModel = profileConfig?.modelOverride || effectiveModel;

  try {
    hijackedMessages = await processBridgeMessages(
      hijackedMessages,
      finalModel,
      body.vcpchatExtensions
        ? { vcpchatExtensions: body.vcpchatExtensions }
        : {},
      nativePromptMarkers
    );
  } catch (error) {
    if (!(error instanceof BridgeNativePromptError)) throw error;
    return res.status(error.statusCode || 422).json({
      error: {
        message: error.message,
        type: error.code || "native_prompt_processing_failed",
      },
    });
  }

  // 2. 解析上游端点
  const stream = body.stream === true;
  const endpoint = resolveUpstreamEndpoint(finalModel, stream);

  // 3. 构建上游请求体
  let upstreamBody;
  switch (endpoint.type) {
    case "anthropic":
      upstreamBody = buildUpstreamAnthropicBody(
        hijackedMessages,
        finalModel,
        body
      );
      break;
    case "gemini":
      upstreamBody = buildUpstreamGeminiBody(
        hijackedMessages,
        finalModel,
        body
      );
      break;
    default:
      upstreamBody = buildUpstreamChatBody(hijackedMessages, finalModel, body);
  }

  // 4. 构建请求头
  const requestToken = extractBearerToken(req.headers.authorization);
  const upstreamKey = runtimeConfig.upstreamKey || requestToken;
  const headers = { "Content-Type": "application/json" };

  if (upstreamKey) headers.Authorization = `Bearer ${upstreamKey}`;
  if (endpoint.type === "anthropic") {
    headers["anthropic-version"] =
      req.headers["anthropic-version"] || "2023-06-01";
    if (req.headers["x-api-key"])
      headers["x-api-key"] = req.headers["x-api-key"];
  }
  if (req.headers["x-goog-api-key"])
    headers["x-goog-api-key"] = req.headers["x-goog-api-key"];

  if (runtimeConfig.debugMode) {
    console.log(
      `[VCPBridgeServer] ${downstreamFormat} → ${endpoint.type} | ${endpoint.url} | hijack=${runtimeConfig.hijackMode}`
    );
  }

  // 5. 发送请求
  let upstreamResponse;
  try {
    upstreamResponse = await fetchTransport(endpoint.url, {
      method: "POST",
      headers,
      body: JSON.stringify(upstreamBody),
    });
  } catch (err) {
    return res.status(502).json({
      error: {
        message: `Upstream fetch failed: ${err.message}`,
        type: "upstream_error",
      },
    });
  }

  // 6. Responses API 下游必须返回 Responses 格式，不能裸透传 chat/anthropic/gemini SSE。
  if (downstreamFormat === "responses") {
    const fallbackModel = resolveModel(finalModel);
    if (stream && upstreamResponse.body) {
      return sendResponsesStreamFromProtocol(res, upstreamResponse, {
        model: fallbackModel,
        apiType: endpoint.type,
      });
    }
    return sendResponsesJsonFromProtocol(res, upstreamResponse, {
      model: fallbackModel,
      apiType: endpoint.type,
    });
  }

  // 7. 专用日记路由必须等待完整工具循环，并只向客户端返回无工具块的结果。
  if (
    req.bridgeProfile === "deepreader-coreading-diary" &&
    downstreamFormat === "chat" &&
    !stream
  ) {
    const text = await upstreamResponse.text();
    try {
      return res
        .status(upstreamResponse.status)
        .json(
          sanitizeDiaryResponsePayload(
            JSON.parse(text),
            body.bridgeDiaryBookTitle || "当前书籍"
          )
        );
    } catch {
      return res.status(upstreamResponse.status).send(text);
    }
  }

  // 8. 其他协议暂时透传响应（保持原始格式，不做响应转换）
  res.status(upstreamResponse.status);
  upstreamResponse.headers.forEach((value, key) => {
    const lower = key.toLowerCase();
    if (
      lower !== "content-encoding" &&
      lower !== "transfer-encoding" &&
      lower !== "content-length"
    ) {
      res.setHeader(key, value);
    }
  });

  if (!upstreamResponse.body) {
    const text = await upstreamResponse.text();
    return res.send(text);
  }

  for await (const chunk of upstreamResponse.body) {
    res.write(chunk);
  }
  res.end();
}

// ============================================================
// Express 路由
// ============================================================

function startServer() {
  const app = express();
  app.use(express.json({ limit: "10mb" }));
  app.use((req, res, next) => {
    if (
      !(
        req.path === "/v1" ||
        req.path.startsWith("/v1/") ||
        req.path.startsWith("/v1beta/")
      )
    )
      return next();
    const requestToken = extractBearerToken(req.headers.authorization);
    if (!requestToken || requestToken !== runtimeConfig.upstreamKey) {
      return res.status(401).json({
        error: {
          message: "Unauthorized (Bearer token required)",
          type: "authentication_error",
        },
      });
    }
    return next();
  });

  // 健康检查
  app.get("/health", (req, res) => {
    res.json({
      ok: true,
      hijackMode: runtimeConfig.hijackMode,
      hasSystemPrompt: Boolean(runtimeConfig.systemPrompt),
      systemPromptChars: runtimeConfig.systemPrompt.length,
      upstreamType: runtimeConfig.upstreamType,
      upstreamUrl: runtimeConfig.upstreamUrl,
      modelMap: runtimeConfig.modelMap,
      configPath: runtimeConfig.configPath,
    });
  });

  app.get("/v1/models", async (req, res) => {
    const requestToken = extractBearerToken(req.headers.authorization);
    const upstreamKey = runtimeConfig.upstreamKey || requestToken;
    const headers = { Accept: "application/json" };
    if (upstreamKey) headers.Authorization = `Bearer ${upstreamKey}`;
    const response = await fetch(
      `${runtimeConfig.upstreamUrl.replace(/\/$/, "")}/v1/models`,
      { headers }
    );
    const text = await response.text();
    res
      .status(response.status)
      .type(response.headers.get("content-type") || "application/json")
      .send(text);
  });

  app.post("/v1/deepreader-coreading-diary", async (req, res) => {
    const body = req.body || {};
    const bookTitle =
      typeof body.bookTitle === "string" ? body.bookTitle.trim() : "";
    const currentDate =
      typeof body.currentDate === "string" ? body.currentDate.trim() : "";
    const currentTime =
      typeof body.currentTime === "string" ? body.currentTime.trim() : "";
    const selectedCount = Number(body.selectedCount);
    const entries = Array.isArray(body.entries) ? body.entries : [];
    const invalidEntryIndex = entries.findIndex(
      (entry) =>
        !entry ||
        typeof entry !== "object" ||
        typeof entry.originalText !== "string" ||
        !entry.originalText.trim() ||
        typeof entry.aiComment !== "string" ||
        !entry.aiComment.trim()
    );
    const validationError =
      (!bookTitle && "bookTitle must be a non-empty string") ||
      (!/^\d{4}-\d{2}-\d{2}$/.test(currentDate) &&
        "currentDate must use YYYY-MM-DD") ||
      (!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(currentTime) &&
        "currentTime must use HH:MM") ||
      (!Number.isInteger(selectedCount) &&
        "selectedCount must be an integer") ||
      (selectedCount < 1 && "selectedCount must be greater than zero") ||
      (!entries.length && "entries must contain at least one record") ||
      (selectedCount !== entries.length &&
        "selectedCount must equal entries.length") ||
      (invalidEntryIndex >= 0 &&
        `entries[${invalidEntryIndex}] must include non-empty originalText and aiComment`);
    if (validationError) {
      return res.status(400).json({
        error: {
          message: validationError,
          type: "invalid_coreading_diary_request",
        },
      });
    }
    const normalizedEntries = entries.map((entry) => ({
      originalText: entry.originalText.trim(),
      aiComment: entry.aiComment.trim(),
      summary: typeof entry.summary === "string" ? entry.summary.trim() : "",
      section: typeof entry.section === "string" ? entry.section.trim() : "",
      position:
        typeof entry.position === "string" || typeof entry.position === "number"
          ? entry.position
          : "",
      time:
        typeof entry.time === "string" || typeof entry.time === "number"
          ? entry.time
          : "",
    }));
    const diaryRequest = {
      userExplicitlyTriggered: true,
      bookTitle,
      currentDate,
      currentTime,
      selectedCount,
      entries: normalizedEntries,
    };
    const messages = [
      { role: "user", content: JSON.stringify(diaryRequest, null, 2) },
    ];
    req.bridgeProfile = "deepreader-coreading-diary";
    await proxyRequest(req, res, {
      messages,
      model:
        typeof body.model === "string" && body.model.trim()
          ? body.model.trim()
          : runtimeConfig.defaultModel,
      body: {
        model: body.model,
        messages,
        stream: false,
        temperature: 0.2,
        bridgeDiaryBookTitle: bookTitle,
      },
      downstreamFormat: "chat",
    });
  });
  // ─── Profile-prefixed routes ─────────────────────────────────────────
  // URL pattern: /v1/:profile/chat/completions, /v1/:profile/responses, etc.
  // These must be registered BEFORE the standard routes to take priority.

  app.post("/v1/:profile/chat/completions", async (req, res, next) => {
    const profile = req.params.profile;
    if (["chat", "responses", "messages", "beta"].includes(profile)) {
      return next();
    }
    req.bridgeProfile = profile;
    const body = req.body || {};
    const messages = Array.isArray(body.messages) ? body.messages : [];
    await proxyRequest(req, res, {
      messages,
      model: body.model,
      body,
      downstreamFormat: "chat",
    });
  });

  app.post("/v1/:profile/responses", async (req, res, next) => {
    const profile = req.params.profile;
    if (["chat", "responses", "messages", "beta"].includes(profile)) {
      return next();
    }
    req.bridgeProfile = profile;
    const body = req.body || {};
    const messages = extractFromResponsesInput(body.input);
    const stream =
      body.stream === true ||
      String(req.headers.accept || "").includes("text/event-stream");
    await proxyRequest(req, res, {
      messages,
      model: body.model,
      body: { ...body, stream },
      downstreamFormat: "responses",
    });
  });

  app.post("/v1/:profile/messages", async (req, res, next) => {
    const profile = req.params.profile;
    if (["chat", "responses", "messages", "beta"].includes(profile)) {
      return next();
    }
    req.bridgeProfile = profile;
    const body = req.body || {};
    const messages = extractFromAnthropicBody(body);
    const stream =
      body.stream === true ||
      String(req.headers.accept || "").includes("text/event-stream");
    await proxyRequest(req, res, {
      messages,
      model: body.model,
      body: { ...body, stream },
      downstreamFormat: "anthropic",
    });
  });

  // ─── Standard routes (no profile prefix) ─────────────────────────────

  // OpenAI Chat Completions
  app.post("/v1/chat/completions", async (req, res) => {
    const body = req.body || {};
    const messages = Array.isArray(body.messages) ? body.messages : [];
    await proxyRequest(req, res, {
      messages,
      model: body.model,
      body,
      downstreamFormat: "chat",
    });
  });

  // OpenAI Responses API
  app.post("/v1/responses", async (req, res) => {
    const body = req.body || {};
    const messages = extractFromResponsesInput(body.input);
    if (typeof body.instructions === "string" && body.instructions.trim()) {
      messages.unshift({ role: "system", content: body.instructions });
    }
    const stream =
      body.stream === true ||
      String(req.headers.accept || "").includes("text/event-stream");
    await proxyRequest(req, res, {
      messages,
      model: body.model,
      body: { ...body, stream },
      downstreamFormat: "responses",
    });
  });

  // Anthropic Messages
  app.post("/v1/messages", async (req, res) => {
    const body = req.body || {};
    const messages = extractFromAnthropicBody(body);
    const stream =
      body.stream === true ||
      String(req.headers.accept || "").includes("text/event-stream");
    await proxyRequest(req, res, {
      messages,
      model: body.model,
      body: { ...body, stream },
      downstreamFormat: "anthropic",
    });
  });

  // Gemini GenerateContent
  app.post(
    /^\/v1beta\/models\/(.+):(generateContent|streamGenerateContent)$/,
    async (req, res) => {
      const body = req.body || {};
      const messages = extractFromGeminiBody(body);
      const model = req.params[0] || runtimeConfig.defaultModel;
      const stream = req.params[1] === "streamGenerateContent";
      await proxyRequest(req, res, {
        messages,
        model,
        body: { ...body, stream },
        downstreamFormat: "gemini",
      });
    }
  );

  // 启动监听
  server = app.listen(runtimeConfig.port, () => {
    console.log(
      `[VCPBridgeServer] Prompt hijack proxy listening on http://127.0.0.1:${runtimeConfig.port}`
    );
    console.log(
      `[VCPBridgeServer] Upstream: ${runtimeConfig.upstreamUrl} (${runtimeConfig.upstreamType})`
    );
    if (runtimeConfig.systemPrompt) {
      console.log(
        `[VCPBridgeServer] System prompt loaded (${runtimeConfig.systemPrompt.length} chars), mode: ${runtimeConfig.hijackMode}`
      );
    }
  });
}

// ============================================================
// 导出
// ============================================================

function setTestDependencies(dependencies = {}) {
  hostDependencies = dependencies;
  if (typeof dependencies.fetch === "function")
    fetchTransport = dependencies.fetch;
  if (dependencies.runtimeConfig) {
    runtimeConfig = { ...runtimeConfig, ...dependencies.runtimeConfig };
  }
}

function resetTestDependencies() {
  hostDependencies = {};
  fetchTransport = (...args) => fetch(...args);
  bridgeOwnedRagProcessor = null;
  bridgeRagInitialization = null;
}

module.exports = {
  initialize,
  shutdown,
  __test: {
    BridgeNativePromptError,
    processBridgeMessages,
    proxyRequest,
    markNativePromptPlaceholders,
    finalizeNativePromptPlaceholders,
    findResidualNativePlaceholder,
    sanitizeDiaryAssistantContent,
    sanitizeDiaryResponsePayload,
    readConfiguredPreprocessorOrder,
    setTestDependencies,
    resetTestDependencies,
  },
};
