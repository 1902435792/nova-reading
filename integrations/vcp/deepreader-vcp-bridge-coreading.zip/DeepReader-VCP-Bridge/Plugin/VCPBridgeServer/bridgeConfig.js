const path = require("path");
const fs = require("fs");
const dotenv = require("dotenv");

const CONFIG_FILE_NAME = "bridge-config.json";
const PLUGIN_DIR = __dirname;
const PROJECT_ROOT = path.resolve(__dirname, "..", "..");
const CONFIG_PATH = path.join(PLUGIN_DIR, CONFIG_FILE_NAME);
const PROFILES_DIR = path.join(PLUGIN_DIR, "profiles");
const PROMPTS_DIR = path.join(PLUGIN_DIR, "prompts");
const MAX_PROMPT_BYTES = 1024 * 1024;
const WINDOWS_DEVICE_NAME = /^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i;

class BridgePromptError extends Error {
  constructor(code, message, statusCode = 422) {
    super(message);
    this.name = "BridgePromptError";
    this.code = code;
    this.statusCode = statusCode;
  }
}

class BridgeProfileError extends BridgePromptError {
  constructor(code, message, statusCode = 422) {
    super(code, message, statusCode);
    this.name = "BridgeProfileError";
  }
}

function promptError(code, message) {
  return new BridgePromptError(code, message);
}

function isPathInside(root, candidate) {
  const relative = path.relative(root, candidate);
  return (
    relative === "" ||
    (!relative.startsWith(`..${path.sep}`) &&
      relative !== ".." &&
      !path.isAbsolute(relative))
  );
}

function parsePromptReference(raw) {
  const rawValue = String(raw || "");
  const value = rawValue.trim();
  if (!value) return null;
  const looksLikePath = /[\\/]/.test(value) || /\.txt$/i.test(value);
  if (!looksLikePath) return null;
  if (rawValue !== value) {
    throw promptError(
      "invalid_prompt_path",
      "Prompt paths cannot have leading or trailing whitespace."
    );
  }
  if (/\0|[\u0001-\u001f\u007f]/u.test(value)) {
    throw promptError(
      "invalid_prompt_path",
      "Prompt path contains invalid characters."
    );
  }
  if (
    path.isAbsolute(value) ||
    path.win32.isAbsolute(value) ||
    /^[a-z]:/i.test(value) ||
    /^(?:\\\\|\/\/|\\\?\\|\\\.\\|\\\?\?\\)/.test(value) ||
    value.includes(":")
  ) {
    throw promptError(
      "invalid_prompt_path",
      "Prompt path must be a safe relative .txt path."
    );
  }

  const segments = value.split(/[\\/]/);
  if (
    segments.some(
      (segment) =>
        !segment ||
        segment === "." ||
        segment === ".." ||
        /[. ]$/.test(segment) ||
        WINDOWS_DEVICE_NAME.test(segment)
    )
  ) {
    throw promptError(
      "invalid_prompt_path",
      "Prompt path contains a forbidden segment."
    );
  }
  if (path.extname(segments.at(-1)).toLowerCase() !== ".txt") {
    throw promptError(
      "invalid_prompt_extension",
      "Prompt files must use the .txt extension."
    );
  }

  if (segments.length === 1) {
    return { rootKind: "legacy", segments };
  }
  if (segments[0].toLowerCase() !== "prompts") {
    throw promptError(
      "invalid_prompt_root",
      "Prompt path must be inside the prompts directory."
    );
  }
  return { rootKind: "prompts", segments: segments.slice(1) };
}

function readSystemPrompt(raw, options = {}) {
  const value = String(raw || "").trim();
  if (!value) return "";
  const reference = parsePromptReference(value);
  if (!reference) return value;

  const pluginDir = path.resolve(options.pluginDir || PLUGIN_DIR);
  const allowedRoot =
    reference.rootKind === "legacy"
      ? pluginDir
      : path.join(pluginDir, "prompts");
  const candidate = path.resolve(allowedRoot, ...reference.segments);
  if (!isPathInside(allowedRoot, candidate)) {
    throw promptError(
      "prompt_path_escape",
      "Prompt path escapes its allowed directory."
    );
  }

  let realRoot;
  try {
    realRoot = fs.realpathSync.native(allowedRoot);
  } catch {
    throw promptError(
      "prompt_root_missing",
      "The allowed Prompt directory is unavailable."
    );
  }

  let current = allowedRoot;
  try {
    for (const segment of reference.segments) {
      current = path.join(current, segment);
      const stats = fs.lstatSync(current);
      if (stats.isSymbolicLink()) {
        throw promptError(
          "prompt_reparse_forbidden",
          "Prompt paths cannot contain links or reparse points."
        );
      }
    }
  } catch (error) {
    if (error instanceof BridgePromptError) throw error;
    throw promptError("prompt_not_found", "Prompt file does not exist.");
  }

  let stats;
  let realCandidate;
  try {
    stats = fs.statSync(candidate);
    realCandidate = fs.realpathSync.native(candidate);
  } catch {
    throw promptError("prompt_not_found", "Prompt file does not exist.");
  }
  if (!stats.isFile())
    throw promptError(
      "prompt_not_file",
      "Prompt path must point to a regular file."
    );
  if (!isPathInside(realRoot, realCandidate)) {
    throw promptError(
      "prompt_path_escape",
      "Prompt file resolves outside its allowed directory."
    );
  }

  const maxBytes = options.maxBytes || MAX_PROMPT_BYTES;
  if (stats.size <= 0)
    throw promptError("prompt_empty", "Prompt file is empty.");
  if (stats.size > maxBytes)
    throw promptError(
      "prompt_too_large",
      `Prompt file exceeds the ${maxBytes}-byte limit.`
    );

  const buffer = fs.readFileSync(candidate);
  if (buffer.length > maxBytes)
    throw promptError(
      "prompt_too_large",
      `Prompt file exceeds the ${maxBytes}-byte limit.`
    );
  let content;
  try {
    content = new TextDecoder("utf-8", { fatal: true }).decode(buffer).trim();
  } catch {
    throw promptError(
      "prompt_invalid_utf8",
      "Prompt file must contain valid UTF-8 text."
    );
  }
  if (!content) throw promptError("prompt_empty", "Prompt file is empty.");
  return content;
}

const DEFAULT_BRIDGE_CONFIG = Object.freeze({
  port: 3100,
  upstreamUrl: "",
  upstreamKey: "",
  upstreamType: "chat",
  defaultModel: "gpt-4.1-mini",
  systemPrompt: "",
  hijackMode: "off",
  modelMap: {},
  availableModels: [],
  modelsTimeoutMs: 3000,
  debugMode: false,
  defaultProfile: "",
});

const DESCRIPTION = Object.freeze({
  port: "Bridge Server 监听端口（独立于主服务器）。端口修改需要重启插件/主服务后生效。",
  upstreamUrl: "上游 API 地址。留空时自动指向本机 VCP 主服务器。",
  upstreamKey:
    "上游 API Key。留空时使用主服务 Key 或透传下游 Authorization Bearer。",
  upstreamType: "上游 API 类型：chat / anthropic / gemini。",
  defaultModel: "默认模型名。下游请求未指定 model 时使用。",
  systemPrompt:
    "注入的 System Prompt（全局兜底）。可直接填写内联文本；文件推荐使用 prompts/ 下的安全相对 .txt 路径，并兼容插件根目录旧裸文件名。",
  hijackMode:
    "劫持模式（全局兜底）：off / replace / prepend / append / merge。当无 Profile 匹配时使用此值。",
  modelMap: '模型名映射对象，例如 {"gpt-4":"gemini-2.5-pro"}。',
  availableModels: "上游模型列表不可用时返回的本地模型 ID 数组。",
  modelsTimeoutMs: "请求上游 /v1/models 的超时毫秒数（500-10000）。",
  debugMode: "是否输出桥接代理调试日志。",
  defaultProfile:
    "默认 Profile 名称。请求未指定 Profile 时自动使用此 Profile（留空则使用全局 systemPrompt/hijackMode）。",
});

// ============================================================
// 基础类型归一化工具
// ============================================================

function normalizeApiType(value) {
  const normalized = String(value || "")
    .trim()
    .toLowerCase();
  if (normalized === "anthropic" || normalized === "claude") return "anthropic";
  if (normalized === "gemini" || normalized === "google") return "gemini";
  return "chat";
}

function normalizeHijackMode(value) {
  const normalized = String(value || "")
    .trim()
    .toLowerCase();
  if (["replace", "prepend", "append", "merge", "off"].includes(normalized)) {
    return normalized;
  }
  return "off";
}

function normalizeBoolean(value, defaultValue = false) {
  if (typeof value === "boolean") return value;
  if (typeof value === "number") return value !== 0;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (["true", "1", "yes", "y", "on"].includes(normalized)) return true;
    if (["false", "0", "no", "n", "off"].includes(normalized)) return false;
  }
  return defaultValue;
}

function normalizePort(value, defaultValue = DEFAULT_BRIDGE_CONFIG.port) {
  const parsed = Number.parseInt(value, 10);
  if (Number.isFinite(parsed) && parsed > 0 && parsed <= 65535) return parsed;
  return defaultValue;
}

function parseModelMap(raw) {
  if (!raw) return {};
  if (typeof raw === "object" && !Array.isArray(raw)) {
    return Object.entries(raw).reduce((acc, [alias, target]) => {
      const cleanAlias = String(alias || "").trim();
      const cleanTarget = String(target || "").trim();
      if (cleanAlias && cleanTarget) acc[cleanAlias] = cleanTarget;
      return acc;
    }, {});
  }
  return String(raw)
    .split(",")
    .reduce((acc, pair) => {
      const idx = pair.indexOf(":");
      if (idx > 0) {
        const alias = pair.slice(0, idx).trim();
        const target = pair.slice(idx + 1).trim();
        if (alias && target) acc[alias] = target;
      }
      return acc;
    }, {});
}

function formatModelMap(modelMap) {
  return Object.entries(parseModelMap(modelMap))
    .map(([alias, target]) => `${alias}:${target}`)
    .join(",");
}

// ============================================================
// 环境变量读取
// ============================================================

function readEnvFileIfExists(filePath) {
  try {
    if (!fs.existsSync(filePath)) return null;
    return dotenv.parse(fs.readFileSync(filePath, "utf8"));
  } catch (error) {
    console.warn(
      `[VCPBridgeConfig] Failed to parse env file ${filePath}:`,
      error.message
    );
    return null;
  }
}

function selectEnvSource() {
  const pluginEnvPath = path.join(PLUGIN_DIR, "config.env");
  const pluginExamplePath = path.join(PLUGIN_DIR, "config.env.example");
  return (
    readEnvFileIfExists(pluginEnvPath) ||
    readEnvFileIfExists(pluginExamplePath) ||
    {}
  );
}

// ============================================================
// 全局配置管理
// ============================================================

function normalizeBridgeConfig(raw = {}, fallbackEnv = {}) {
  const mainServerPort =
    raw.mainServerPort || fallbackEnv.PORT || process.env.PORT || 6005;
  const defaultUpstream = `http://127.0.0.1:${mainServerPort}`;
  const rawUpstreamUrl =
    raw.upstreamUrl ??
    raw.BRIDGE_UPSTREAM_URL ??
    fallbackEnv.BRIDGE_UPSTREAM_URL ??
    "";

  return {
    port: normalizePort(raw.port ?? raw.BRIDGE_PORT ?? fallbackEnv.BRIDGE_PORT),
    upstreamUrl: String(rawUpstreamUrl || defaultUpstream)
      .trim()
      .replace(/\/+$/, ""),
    upstreamKey: String(
      raw.upstreamKey ??
        raw.BRIDGE_UPSTREAM_KEY ??
        fallbackEnv.BRIDGE_UPSTREAM_KEY ??
        fallbackEnv.Key ??
        process.env.Key ??
        ""
    ),
    upstreamType: normalizeApiType(
      raw.upstreamType ??
        raw.BRIDGE_UPSTREAM_TYPE ??
        fallbackEnv.BRIDGE_UPSTREAM_TYPE
    ),
    defaultModel:
      String(
        raw.defaultModel ??
          raw.BRIDGE_MODEL ??
          fallbackEnv.BRIDGE_MODEL ??
          DEFAULT_BRIDGE_CONFIG.defaultModel
      ).trim() || DEFAULT_BRIDGE_CONFIG.defaultModel,
    systemPrompt: String(
      raw.systemPrompt ??
        raw.BRIDGE_SYSTEM_PROMPT ??
        fallbackEnv.BRIDGE_SYSTEM_PROMPT ??
        ""
    ),
    hijackMode: normalizeHijackMode(
      raw.hijackMode ?? raw.BRIDGE_HIJACK_MODE ?? fallbackEnv.BRIDGE_HIJACK_MODE
    ),
    modelMap: parseModelMap(
      raw.modelMap ?? raw.BRIDGE_MODEL_MAP ?? fallbackEnv.BRIDGE_MODEL_MAP
    ),
    availableModels: Array.from(
      new Set(
        (Array.isArray(raw.availableModels) ? raw.availableModels : [])
          .map((model) => String(model || "").trim())
          .filter(Boolean)
      )
    ),
    modelsTimeoutMs: Math.min(
      10000,
      Math.max(
        500,
        Number(raw.modelsTimeoutMs) || DEFAULT_BRIDGE_CONFIG.modelsTimeoutMs
      )
    ),
    debugMode: normalizeBoolean(
      raw.debugMode ?? raw.DebugMode ?? fallbackEnv.DebugMode,
      DEFAULT_BRIDGE_CONFIG.debugMode
    ),
    defaultProfile: String(raw.defaultProfile ?? "").trim(),
  };
}

function buildConfigFromEnv(env = {}) {
  return normalizeBridgeConfig(
    {
      BRIDGE_PORT: env.BRIDGE_PORT,
      BRIDGE_UPSTREAM_URL: env.BRIDGE_UPSTREAM_URL,
      BRIDGE_UPSTREAM_KEY: env.BRIDGE_UPSTREAM_KEY,
      BRIDGE_UPSTREAM_TYPE: env.BRIDGE_UPSTREAM_TYPE,
      BRIDGE_MODEL: env.BRIDGE_MODEL,
      BRIDGE_SYSTEM_PROMPT: env.BRIDGE_SYSTEM_PROMPT,
      BRIDGE_HIJACK_MODE: env.BRIDGE_HIJACK_MODE,
      BRIDGE_MODEL_MAP: env.BRIDGE_MODEL_MAP,
      DebugMode: env.DebugMode,
    },
    env
  );
}

function readJsonConfig() {
  const parsed = JSON.parse(fs.readFileSync(CONFIG_PATH, "utf8"));
  return normalizeBridgeConfig(parsed);
}

function writeUtf8FileAtomic(filePath, content) {
  const directory = path.dirname(filePath);
  fs.mkdirSync(directory, { recursive: true });
  const temporaryPath = path.join(
    directory,
    `.${path.basename(filePath)}.${process.pid}.${Date.now()}.${Math.random()
      .toString(16)
      .slice(2)}.tmp`
  );

  try {
    fs.writeFileSync(temporaryPath, content, { encoding: "utf8", flag: "wx" });
    fs.renameSync(temporaryPath, filePath);
  } finally {
    try {
      fs.rmSync(temporaryPath, { force: true });
    } catch {
      // The target file has already been replaced; temporary cleanup is best-effort.
    }
  }
}

function writeJsonConfig(config) {
  const payload = {
    ...normalizeBridgeConfig(config),
    description: DESCRIPTION,
  };
  writeUtf8FileAtomic(CONFIG_PATH, `${JSON.stringify(payload, null, 2)}\n`);
  return payload;
}

function migrateBridgeConfig() {
  if (fs.existsSync(CONFIG_PATH)) {
    return readJsonConfig();
  }

  const env = selectEnvSource();
  const config = buildConfigFromEnv(env);
  writeJsonConfig(config);
  console.log(
    `[VCPBridgeConfig] Created ${path.relative(
      PROJECT_ROOT,
      CONFIG_PATH
    )} from ${Object.keys(env).length ? "env/example" : "defaults"}.`
  );
  return config;
}

function readBridgeConfig() {
  return migrateBridgeConfig();
}

function saveBridgeConfig(config) {
  return writeJsonConfig(config);
}

function toEnvCompatConfig(config) {
  const normalized = normalizeBridgeConfig(config);
  return {
    BRIDGE_PORT: normalized.port,
    BRIDGE_UPSTREAM_URL: normalized.upstreamUrl,
    BRIDGE_UPSTREAM_KEY: normalized.upstreamKey,
    BRIDGE_UPSTREAM_TYPE: normalized.upstreamType,
    BRIDGE_MODEL: normalized.defaultModel,
    BRIDGE_SYSTEM_PROMPT: normalized.systemPrompt,
    BRIDGE_HIJACK_MODE: normalized.hijackMode,
    BRIDGE_MODEL_MAP: formatModelMap(normalized.modelMap),
    DebugMode: normalized.debugMode,
  };
}

// ============================================================
// Profile 管理
// ============================================================

/**
 * 确保 profiles 目录存在
 */
function ensureProfilesDir() {
  if (!fs.existsSync(PROFILES_DIR)) {
    fs.mkdirSync(PROFILES_DIR, { recursive: true });
  }
}

/**
 * 对 profile 数据进行归一化和验证
 * @param {string} name - Profile 文件名（不含扩展名）
 * @param {object} raw - 原始 profile 数据
 * @returns {object} 归一化后的 profile 对象
 */
function normalizeProfile(name, raw = {}) {
  return {
    name: String(name || ""),
    displayName: String(raw.displayName || name || "").trim(),
    systemPrompt: String(raw.systemPrompt || "").trim(),
    hijackMode: normalizeHijackMode(raw.hijackMode),
    modelOverride: String(raw.modelOverride || "").trim(),
    responseMode: ["structured", "assistant", "passthrough"].includes(
      String(raw.responseMode || "")
        .trim()
        .toLowerCase()
    )
      ? String(raw.responseMode).trim().toLowerCase()
      : "passthrough",
    description: String(raw.description || "").trim(),
  };
}

function validateProfileDocument(name, raw) {
  if (!isValidProfileName(name)) {
    throw new BridgeProfileError(
      "invalid_profile_name",
      "Profile name must use 1-64 lowercase letters, digits, hyphens or underscores.",
      400
    );
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    throw new BridgeProfileError(
      "invalid_profile_body",
      "Profile data must be a JSON object.",
      400
    );
  }
  if (raw.name !== undefined && raw.name !== name) {
    throw new BridgeProfileError(
      "profile_name_mismatch",
      "Profile name in JSON must match its file or route name exactly.",
      422
    );
  }
  if (
    raw.hijackMode !== undefined &&
    !["off", "replace", "prepend", "append", "merge"].includes(raw.hijackMode)
  ) {
    throw new BridgeProfileError(
      "invalid_hijack_mode",
      "hijackMode must be off, replace, prepend, append or merge.",
      422
    );
  }
  if (
    raw.responseMode !== undefined &&
    !["structured", "assistant", "passthrough"].includes(raw.responseMode)
  ) {
    throw new BridgeProfileError(
      "invalid_response_mode",
      "responseMode must be structured, assistant or passthrough.",
      422
    );
  }

  const normalized = normalizeProfile(name, raw);
  if (normalized.systemPrompt) readSystemPrompt(normalized.systemPrompt);
  return normalized;
}

/**
 * 验证 profile name 是否合法（防路径穿越）
 * @param {string} name
 * @returns {boolean}
 */
function isValidProfileName(name) {
  return typeof name === "string" && /^[a-z0-9][a-z0-9_-]{0,63}$/.test(name);
}

/**
 * 判断指定 profile 是否存在
 * @param {string} name
 * @returns {boolean}
 */
function profileExists(name) {
  if (!isValidProfileName(name)) return false;
  return fs.existsSync(path.join(PROFILES_DIR, `${name}.json`));
}

/**
 * 列出所有 profile
 * @returns {Array<object>} profile 对象数组
 */
function inspectProfiles() {
  ensureProfilesDir();
  const profiles = [];
  const invalidProfiles = [];
  const fileNames = fs
    .readdirSync(PROFILES_DIR)
    .filter(
      (fileName) =>
        fileName.endsWith(".json") && !fileName.endsWith(".example.json")
    )
    .sort((left, right) => left.localeCompare(right, "en"));

  for (const fileName of fileNames) {
    const name = fileName.replace(/\.json$/, "");
    try {
      const filePath = path.join(PROFILES_DIR, fileName);
      const parsed = JSON.parse(fs.readFileSync(filePath, "utf8"));
      profiles.push(validateProfileDocument(name, parsed));
    } catch (error) {
      invalidProfiles.push({
        fileName,
        name,
        code: error.code || "invalid_profile_json",
        message:
          error instanceof SyntaxError
            ? "Profile file is not valid JSON."
            : error.message || "Profile file is invalid.",
      });
    }
  }

  return { profiles, invalidProfiles };
}

function listProfiles() {
  const result = inspectProfiles();
  if (result.invalidProfiles.length > 0) {
    const error = new BridgeProfileError(
      "invalid_profile_files",
      `${result.invalidProfiles.length} Bridge Profile file(s) are invalid.`,
      422
    );
    error.invalidProfiles = result.invalidProfiles;
    throw error;
  }
  return result.profiles;
}

/**
 * 读取单个 profile
 * @param {string} name - Profile 名称
 * @returns {object|null} profile 对象或 null
 */
function readProfile(name) {
  if (!isValidProfileName(name)) return null;
  const filePath = path.join(PROFILES_DIR, `${name}.json`);
  if (!fs.existsSync(filePath)) return null;
  try {
    const parsed = JSON.parse(fs.readFileSync(filePath, "utf8"));
    return validateProfileDocument(name, parsed);
  } catch (error) {
    if (error instanceof BridgePromptError) throw error;
    throw new BridgeProfileError(
      "invalid_profile_json",
      "Profile file is not valid JSON.",
      422
    );
  }
}

/**
 * 保存/创建 profile
 * @param {string} name - Profile 名称
 * @param {object} data - Profile 数据
 * @returns {object} 归一化后的 profile
 */
function saveProfile(name, data = {}) {
  const normalized = validateProfileDocument(name, data);
  ensureProfilesDir();
  const filePath = path.join(PROFILES_DIR, `${name}.json`);
  writeUtf8FileAtomic(filePath, `${JSON.stringify(normalized, null, 2)}\n`);
  return normalized;
}

/**
 * 删除 profile
 * @param {string} name - Profile 名称
 * @returns {boolean} 是否成功删除
 */
function deleteProfile(name) {
  if (!isValidProfileName(name)) return false;
  const filePath = path.join(PROFILES_DIR, `${name}.json`);
  if (!fs.existsSync(filePath)) return false;
  try {
    fs.unlinkSync(filePath);
    return true;
  } catch {
    return false;
  }
}

// ============================================================
// 导出
// ============================================================

module.exports = {
  // 路径常量与 Prompt 安全加载
  CONFIG_PATH,
  CONFIG_FILE_NAME,
  PROFILES_DIR,
  PROMPTS_DIR,
  MAX_PROMPT_BYTES,
  BridgePromptError,
  BridgeProfileError,
  parsePromptReference,
  readSystemPrompt,
  DESCRIPTION,

  // 全局配置管理
  normalizeBridgeConfig,
  migrateBridgeConfig,
  readBridgeConfig,
  saveBridgeConfig,
  toEnvCompatConfig,
  parseModelMap,

  // Profile 管理
  normalizeProfile,
  validateProfileDocument,
  isValidProfileName,
  profileExists,
  inspectProfiles,
  listProfiles,
  readProfile,
  saveProfile,
  deleteProfile,
};
