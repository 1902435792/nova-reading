const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");

require("../../modules/dotenvPatch.js");
const dotenv = require("dotenv");

// Prefer root VCP config.env (pm_cwd of vcp-main). Fallback to tracked example so CI
// without local secrets still validates the public key contract.
const ROOT_DIR = path.resolve(__dirname, "..", "..");
const ROOT_CONFIG_ENV = path.join(ROOT_DIR, "config.env");
const ROOT_CONFIG_ENV_EXAMPLE = path.join(ROOT_DIR, "config.env.example");
const ROOT_CONFIG_PATH = fs.existsSync(ROOT_CONFIG_ENV)
  ? ROOT_CONFIG_ENV
  : ROOT_CONFIG_ENV_EXAMPLE;

dotenv.config({ path: ROOT_CONFIG_PATH });

const bridge = require("./bridgeserver.js");
const {
  BridgeNativePromptError,
  processBridgeMessages,
  markNativePromptPlaceholders,
  finalizeNativePromptPlaceholders,
  findResidualNativePlaceholder,
  sanitizeDiaryAssistantContent,
  sanitizeDiaryResponsePayload,
  readConfiguredPreprocessorOrder,
  resetTestDependencies,
  setTestDependencies,
} = bridge.__test;
const {
  isValidProfileName,
  readProfile,
  readSystemPrompt,
} = require("./bridgeConfig");

function readEnvKeyFromFile(filePath, key) {
  const parsed = dotenv.parse(fs.readFileSync(filePath, "utf8"));
  return parsed[key];
}

function createPluginManager(calls, options = {}) {
  const processors = new Map();
  processors.set("VCPTavern", {
    async processMessages(messages) {
      calls.push("VCPTavern");
      return messages;
    },
  });
  processors.set("VCPTimeLine", {
    async processMessages(messages) {
      calls.push("VCPTimeLine");
      return messages;
    },
  });
  processors.set("OpenHerPersona", {
    async processMessages(messages) {
      calls.push("OpenHerPersona");
      return messages;
    },
  });
  processors.set("OneRing", {
    async processMessages(messages) {
      calls.push("OneRing");
      return messages;
    },
  });
  processors.set("ContextFoldingV2", {
    async processMessages(messages) {
      calls.push("ContextFoldingV2");
      return messages;
    },
  });

  return {
    projectBasePath: process.cwd(),
    messagePreprocessors: processors,
    getAllPlaceholderValues() {
      return new Map();
    },
    getIndividualPluginDescriptions() {
      return new Map();
    },
    getResolvedPluginConfigValue() {
      return undefined;
    },
    async executeMessagePreprocessor(name, messages, config) {
      return processors.get(name).processMessages(messages, config);
    },
    ...options,
  };
}

test.afterEach(() => {
  // Restore the value loaded from real root config.env / example, not a synthetic override.
  const fromFile = readEnvKeyFromFile(ROOT_CONFIG_PATH, "VarTimelineNova");
  if (fromFile === undefined) {
    delete process.env.VarTimelineNova;
  } else {
    process.env.VarTimelineNova = fromFile;
  }
  resetTestDependencies();
});

test("root config.env defines VarTimelineNova for real expansion", () => {
  const fromFile = readEnvKeyFromFile(ROOT_CONFIG_PATH, "VarTimelineNova");
  assert.ok(
    fromFile && String(fromFile).trim(),
    `VarTimelineNova must be defined in ${path.basename(ROOT_CONFIG_PATH)}`
  );
  assert.equal(
    process.env.VarTimelineNova,
    fromFile,
    "process.env.VarTimelineNova must come from real root config, not a synthetic test override"
  );
  // Prefer TVS file reference so long timeline text is not hardcoded in config.env.
  if (String(fromFile).toLowerCase().endsWith(".txt")) {
    const tvsPath = path.join(ROOT_DIR, "TVStxt", path.basename(fromFile));
    assert.ok(
      fs.existsSync(tvsPath),
      `VarTimelineNova TVS file missing: ${tvsPath}`
    );
    const body = fs.readFileSync(tvsPath, "utf8");
    assert.match(body, /Nova/);
    assert.doesNotMatch(body, /CoReadingMCP 阅读系统/);
  }
});

test("Bridge follows preprocessor_order.json after native variable expansion", async () => {
  const calls = [];
  // Intentionally do NOT set process.env.VarTimelineNova here — it must expand
  // from the real root config.env loaded at module init.
  const configured = process.env.VarTimelineNova;
  assert.ok(
    configured && String(configured).trim(),
    "VarTimelineNova must be present from real config.env before expansion"
  );
  const pluginManager = createPluginManager(calls);
  const ragProcessor = {
    async processMessages(messages) {
      calls.push("RAGDiaryPlugin");
      return messages.map((message) => ({
        ...message,
        content:
          typeof message.content === "string"
            ? message.content.replace(
                "[[Nova日记本::Time::Group::TagMemo+]]",
                "synthetic diary context"
              )
            : message.content,
      }));
    },
  };
  setTestDependencies({ pluginManager, ragProcessor });

  const result = await processBridgeMessages(
    [
      {
        role: "system",
        content:
          "prefix {{VarTimelineNova}} [[Nova日记本::Time::Group::TagMemo+]] suffix",
      },
      { role: "user", content: "synthetic query" },
    ],
    "synthetic-model"
  );

  const systemText = result.find(
    (message) => message.role === "system"
  ).content;
  assert.match(systemText, /Nova/);
  assert.match(systemText, /synthetic diary context/);
  assert.doesNotMatch(systemText, /\{\{VarTimelineNova\}\}/);
  assert.doesNotMatch(systemText, /\[\[Nova日记本::Time::Group::TagMemo\+\]\]/);
  // Must not leave the unresolved-config fallback marker either.
  assert.doesNotMatch(systemText, /\[未配置 VarTimelineNova\]/);
  assert.deepEqual(calls, [
    "VCPTavern",
    "RAGDiaryPlugin",
    "VCPTimeLine",
    "OpenHerPersona",
    "OneRing",
    "ContextFoldingV2",
  ]);
  assert.deepEqual(readConfiguredPreprocessorOrder().slice(0, 7), [
    "VCPTavern",
    "ImageProcessor",
    "RAGDiaryPlugin",
    "VCPTimeLine",
    "OpenHerPersona",
    "OneRing",
    "ContextFoldingV2",
  ]);
});

test("ordinary prompt text remains unchanged", async () => {
  const calls = [];
  const pluginManager = createPluginManager(calls);
  const ragProcessor = {
    async processMessages(messages) {
      calls.push("RAGDiaryPlugin");
      return messages;
    },
  };
  setTestDependencies({ pluginManager, ragProcessor });

  const result = await processBridgeMessages(
    [{ role: "system", content: "ordinary prompt" }],
    "synthetic-model"
  );
  assert.equal(result[0].content, "ordinary prompt");
});

test("unresolved placeholders originating in the native prompt still fail closed", async () => {
  const calls = [];
  const pluginManager = createPluginManager(calls);
  const ragProcessor = {
    async processMessages(messages) {
      calls.push("RAGDiaryPlugin");
      // Intentionally leave diary placeholders untouched so provenance tracking fails closed.
      return messages;
    },
  };
  setTestDependencies({ pluginManager, ragProcessor });

  const previousMissing = process.env.VarTimelineNovaMissingForTest;
  delete process.env.VarTimelineNovaMissingForTest;
  const trackedPrompt = markNativePromptPlaceholders(
    "{{VarTimelineNovaMissingForTest}} [[Nova日记本::Time::Group::TagMemo+]]"
  );
  try {
    await assert.rejects(
      processBridgeMessages(
        [{ role: "system", content: trackedPrompt.prompt }],
        "synthetic-model",
        {},
        trackedPrompt.markers
      ),
      (error) =>
        error instanceof BridgeNativePromptError &&
        error.code === "native_placeholder_unresolved" &&
        /\{\{VarTimelineNovaMissingForTest\}\}/.test(error.message)
    );
  } finally {
    if (previousMissing === undefined) {
      delete process.env.VarTimelineNovaMissingForTest;
    } else {
      process.env.VarTimelineNovaMissingForTest = previousMissing;
    }
  }
});

test("missing host plugin manager fails before any upstream transport", async () => {
  setTestDependencies({});
  await assert.rejects(
    processBridgeMessages(
      [{ role: "system", content: "ordinary prompt" }],
      "model"
    ),
    (error) =>
      error instanceof BridgeNativePromptError &&
      error.code === "native_preprocessor_unavailable"
  );
});

test("final upstream body contains expanded native contexts", async () => {
  const calls = [];
  const captured = [];
  // Use real root config for {{VarTimelineNova}}; diary remains synthetic via RAG mock.
  assert.ok(
    process.env.VarTimelineNova && String(process.env.VarTimelineNova).trim(),
    "VarTimelineNova must come from real root config.env"
  );
  const pluginManager = createPluginManager(calls);
  const ragProcessor = {
    async processMessages(messages) {
      calls.push("RAGDiaryPlugin");
      return messages.map((message) => ({
        ...message,
        content:
          typeof message.content === "string"
            ? message.content.replace(
                "[[Nova日记本::Time::Group::TagMemo+]]",
                "synthetic diary context"
              )
            : message.content,
      }));
    },
  };
  setTestDependencies({
    pluginManager,
    ragProcessor,
    runtimeConfig: {
      upstreamUrl: "http://synthetic.invalid/v1",
      upstreamType: "chat",
      upstreamKey: "synthetic-upstream-key",
      defaultModel: "synthetic-model",
      modelMap: {},
      hijackMode: "replace",
      systemPrompt: "{{VarTimelineNova}} [[Nova日记本::Time::Group::TagMemo+]]",
      debugMode: false,
    },
    fetch: async (url, options) => {
      captured.push({ url, options, body: JSON.parse(options.body) });
      return new Response(
        JSON.stringify({
          id: "synthetic",
          choices: [{ message: { role: "assistant", content: "ok" } }],
        }),
        { status: 200, headers: { "content-type": "application/json" } }
      );
    },
  });

  const request = {
    method: "POST",
    path: "/v1/chat/completions",
    params: {},
    query: {},
    headers: { authorization: "Bearer synthetic-local-key" },
    body: {
      model: "synthetic-model",
      messages: [{ role: "user", content: "synthetic query" }],
    },
  };
  const response = {
    headersSent: false,
    writableEnded: false,
    destroyed: false,
    statusCode: 200,
    headers: {},
    status(code) {
      this.statusCode = code;
      return this;
    },
    setHeader(name, value) {
      this.headers[name] = value;
    },
    json(payload) {
      this.payload = payload;
      this.headersSent = true;
      return this;
    },
    send(payload) {
      this.payload = payload;
      this.headersSent = true;
      return this;
    },
    write() {},
    end() {
      this.writableEnded = true;
    },
  };

  await bridge.__test.proxyRequest(request, response, {
    messages: request.body.messages,
    model: request.body.model,
    body: request.body,
    downstreamFormat: "chat",
  });
  assert.equal(captured.length, 1);
  assert.equal(
    captured[0].options.headers.Authorization,
    "Bearer synthetic-upstream-key"
  );
  const systemText = captured[0].body.messages.find(
    (message) => message.role === "system"
  ).content;
  assert.match(systemText, /Nova/);
  assert.match(systemText, /synthetic diary context/);
  assert.doesNotMatch(systemText, /\{\{VarTimelineNova\}\}/);
  assert.doesNotMatch(systemText, /\[未配置 VarTimelineNova\]/);
  assert.doesNotMatch(systemText, /\[\[Nova日记本::Time::Group::TagMemo\+\]\]/);
  assert.doesNotMatch(JSON.stringify(captured[0].body.messages), /VCP_NATIVE_/);
});

function createMockResponse() {
  return {
    headersSent: false,
    writableEnded: false,
    destroyed: false,
    statusCode: 200,
    headers: {},
    payload: null,
    status(code) {
      this.statusCode = code;
      return this;
    },
    setHeader(name, value) {
      this.headers[name] = value;
    },
    json(payload) {
      this.payload = payload;
      this.headersSent = true;
      return this;
    },
    send(payload) {
      this.payload = payload;
      this.headersSent = true;
      return this;
    },
    write() {},
    end() {
      this.writableEnded = true;
    },
  };
}

test("deepreader-coreading-diary profile exists and loads pure diary prompt safely", () => {
  const name = "deepreader-coreading-diary";
  assert.equal(isValidProfileName(name), true);
  const profile = readProfile(name);
  assert.ok(profile, "profiles/deepreader-coreading-diary.json must exist");
  assert.equal(profile.name, name);
  assert.equal(profile.modelOverride, "");
  assert.equal(profile.responseMode, "passthrough");
  assert.equal(profile.hijackMode, "replace");
  assert.equal(profile.systemPrompt, "prompts/deepreader-coreading-diary.txt");
  const prompt = readSystemPrompt(profile.systemPrompt);
  assert.match(prompt, /DailyNote/);
  assert.match(prompt, /<<<\[TOOL_REQUEST\]>>>/);
  assert.doesNotMatch(prompt, /\bannotate\b/i);
  assert.doesNotMatch(prompt, /\bsilent\b/i);
  assert.doesNotMatch(prompt, /NEW_BLOCKS/);
});

test("coreading prompt stays free of DailyNote tool protocol and uses 30-220 comment length", () => {
  const prompt = readSystemPrompt("coreading.txt");
  assert.match(prompt, /30[–-]220/);
  assert.doesNotMatch(prompt, /100 个中文字符/);
  assert.doesNotMatch(prompt, /1000 个中文字符/);
  assert.doesNotMatch(prompt, /DailyNote/);
  assert.doesNotMatch(prompt, /TOOL_REQUEST/);
  assert.doesNotMatch(prompt, /DailyNoteStart/);
  assert.doesNotMatch(prompt, /<<<\[TOOL_REQUEST\]>>>/);
  assert.match(prompt, /silent/);
  assert.match(prompt, /annotate/);
});

test("bridge-config.json defaults debugMode to false", () => {
  const config = JSON.parse(
    fs.readFileSync(path.join(__dirname, "bridge-config.json"), "utf8")
  );
  assert.equal(config.debugMode, false);
});

test("native placeholder detection follows prompt provenance instead of scanning user or recalled prose", () => {
  const tracked = markNativePromptPlaceholders(
    "prefix {{VarTimelineNova}} [[Nova日记本::Time::Group::TagMemo+]] suffix"
  );
  assert.equal(tracked.markers.length, 2);
  assert.equal(
    findResidualNativePlaceholder(
      [{ role: "system", content: tracked.prompt }],
      tracked.markers
    ),
    "{{VarTimelineNova}}"
  );

  const expanded = tracked.prompt
    .replace("{{VarTimelineNova}}", "timeline expanded")
    .replace(
      "[[Nova日记本::Time::Group::TagMemo+]]",
      "recalled prose that quotes {{VarFromDiary}} and [[示例日记本::Time]]"
    );
  const finalized = finalizeNativePromptPlaceholders(
    [{ role: "system", content: expanded }],
    tracked.markers
  );
  assert.equal(finalized.residual, null);
  assert.match(finalized.messages[0].content, /\{\{VarFromDiary\}\}/);
  assert.match(finalized.messages[0].content, /\[\[示例日记本::Time\]\]/);
  assert.doesNotMatch(finalized.messages[0].content, /VCP_NATIVE_/);

  assert.equal(
    findResidualNativePlaceholder(
      [
        { role: "user", content: "正文引用 {{VarTimelineNova}}" },
        {
          role: "assistant",
          content: [{ type: "text", text: "[[Nova日记本::Time]]" }],
        },
      ],
      []
    ),
    null
  );
});

test("native prompt provenance covers every supported syntax and duplicate occurrence", () => {
  const tokens = [
    "{{VarOne}}",
    "{{TarTwo}}",
    "[[Nova日记本::Time]]",
    "<<Nova日记本::Time>>",
    "《《Nova日记本::Time》》",
    "{{Nova日记本::Time}}",
    "{{VarOne}}",
  ];
  const plainText = "plain prompt text remains byte-for-byte stable";
  const tracked = markNativePromptPlaceholders(
    `${plainText} ${tokens.join(" | ")}`
  );
  assert.deepEqual(
    tracked.markers.map((marker) => marker.token),
    tokens
  );
  assert.equal(
    new Set(tracked.markers.map((marker) => marker.open)).size,
    tokens.length
  );

  for (const token of tokens.slice(0, -1)) {
    const single = markNativePromptPlaceholders(token);
    assert.equal(
      findResidualNativePlaceholder(
        [{ role: "system", content: single.prompt }],
        single.markers
      ),
      token
    );
  }

  let expanded = tracked.prompt;
  tracked.markers.forEach((marker, index) => {
    expanded = expanded.replace(marker.token, `expanded-${index}`);
  });
  const finalized = finalizeNativePromptPlaceholders(
    [
      { role: "system", content: expanded },
      { role: "user", content: `ordinary quotation ${tokens.join(" ")}` },
    ],
    tracked.markers
  );
  assert.equal(finalized.residual, null);
  assert.match(finalized.messages[0].content, new RegExp(plainText));
  assert.equal(
    finalized.messages[1].content,
    `ordinary quotation ${tokens.join(" ")}`
  );
  assert.doesNotMatch(JSON.stringify(finalized.messages), /VCP_NATIVE_/);
});

test("native prompt provenance fails closed when a tracking marker is lost or duplicated", () => {
  const tracked = markNativePromptPlaceholders("prefix {{VarTracked}} suffix");
  assert.throws(
    () =>
      finalizeNativePromptPlaceholders(
        [{ role: "system", content: "prefix expanded suffix" }],
        tracked.markers
      ),
    (error) =>
      error instanceof BridgeNativePromptError &&
      error.code === "native_placeholder_tracking_failed"
  );
  assert.throws(
    () =>
      finalizeNativePromptPlaceholders(
        [{ role: "system", content: `${tracked.prompt} ${tracked.prompt}` }],
        tracked.markers
      ),
    (error) =>
      error instanceof BridgeNativePromptError &&
      error.code === "native_placeholder_tracking_failed"
  );
});

test("two consecutive native prompt expansions stay isolated when recall introduces placeholder-shaped prose", async () => {
  const calls = [];
  const pluginManager = createPluginManager(calls);
  const ragProcessor = {
    async processMessages(messages) {
      calls.push("RAGDiaryPlugin");
      return messages.map((message) => ({
        ...message,
        content:
          typeof message.content === "string"
            ? message.content.replace(
                "[[Nova日记本::Time::Group::TagMemo+]]",
                "recalled prose contains {{VarQuotedByMemory}} and [[示例日记本::Time]]"
              )
            : message.content,
      }));
    },
  };
  setTestDependencies({ pluginManager, ragProcessor });

  const run = async (focus) => {
    const tracked = markNativePromptPlaceholders(
      "{{VarTimelineNova}} [[Nova日记本::Time::Group::TagMemo+]]"
    );
    const result = await processBridgeMessages(
      [
        { role: "system", content: tracked.prompt },
        { role: "user", content: `CURRENT_VISIBLE_FOCUS=${focus}` },
      ],
      "synthetic-model",
      {},
      tracked.markers
    );
    return result.find((message) => message.role === "system")?.content || "";
  };

  const first = await run("synthetic-focus-1");
  const second = await run("synthetic-focus-2");
  for (const systemText of [first, second]) {
    assert.match(systemText, /Nova/);
    assert.match(systemText, /\{\{VarQuotedByMemory\}\}/);
    assert.match(systemText, /\[\[示例日记本::Time\]\]/);
    assert.doesNotMatch(systemText, /VCP_NATIVE_/);
  }
  assert.equal(calls.filter((name) => name === "RAGDiaryPlugin").length, 2);
});

test("sanitizeDiaryResponsePayload strips tool blocks from diary responses", () => {
  const cleaned = sanitizeDiaryAssistantContent(
    "<<<[TOOL_REQUEST]>>>maid:「始」Nova「末」<<<[END_TOOL_REQUEST]>>>\n<<<DailyNoteStart>>>x<<<DailyNoteEnd>>>\n已写入",
    "fallback"
  );
  assert.equal(cleaned, "已写入");
  const payload = sanitizeDiaryResponsePayload(
    {
      choices: [
        {
          message: {
            role: "assistant",
            content: "<<<[TOOL_REQUEST]>>>secret<<<[END_TOOL_REQUEST]>>>",
            tool_calls: [{ id: "x" }],
          },
        },
      ],
    },
    "示例书"
  );
  assert.equal(
    payload.choices[0].message.content,
    "《示例书》的本次共读日记已写入。"
  );
  assert.equal(payload.choices[0].message.tool_calls, undefined);
});

test("diary route profile resolves and keeps client model when modelOverride is empty", async () => {
  const calls = [];
  const captured = [];
  const pluginManager = createPluginManager(calls);
  const ragProcessor = {
    async processMessages(messages) {
      calls.push("RAGDiaryPlugin");
      return messages;
    },
  };
  setTestDependencies({
    pluginManager,
    ragProcessor,
    runtimeConfig: {
      upstreamUrl: "http://synthetic.invalid/v1",
      upstreamType: "chat",
      upstreamKey: "synthetic-upstream-key",
      defaultModel: "bridge-default-model",
      modelMap: {},
      hijackMode: "off",
      systemPrompt: "",
      debugMode: false,
    },
    fetch: async (url, options) => {
      captured.push({ url, options, body: JSON.parse(options.body) });
      return new Response(
        JSON.stringify({
          id: "synthetic-diary",
          choices: [
            {
              message: {
                role: "assistant",
                content:
                  "<<<[TOOL_REQUEST]>>>maid:「始」Nova「末」<<<[END_TOOL_REQUEST]>>>\n工具内部",
              },
            },
          ],
        }),
        { status: 200, headers: { "content-type": "application/json" } }
      );
    },
  });

  const clientModel = "client-preferred-model";
  const messages = [
    {
      role: "user",
      content: JSON.stringify({
        userExplicitlyTriggered: true,
        bookTitle: "示例书",
        currentDate: "2026-07-13",
        currentTime: "09:07",
        selectedCount: 1,
        entries: [
          {
            originalText: "原文片段",
            aiComment: "页边短评",
          },
        ],
      }),
    },
  ];
  const request = {
    method: "POST",
    path: "/v1/deepreader-coreading-diary",
    bridgeProfile: "deepreader-coreading-diary",
    params: {},
    query: {},
    headers: { authorization: "Bearer synthetic-local-key" },
    body: {
      model: clientModel,
      messages,
      stream: false,
      bridgeDiaryBookTitle: "示例书",
    },
  };
  const response = createMockResponse();

  await bridge.__test.proxyRequest(request, response, {
    messages,
    model: clientModel,
    body: request.body,
    downstreamFormat: "chat",
  });

  assert.equal(captured.length, 1);
  assert.equal(captured[0].body.model, clientModel);
  const systemText = captured[0].body.messages.find(
    (message) => message.role === "system"
  )?.content;
  assert.ok(systemText, "diary route must inject diary system prompt");
  assert.match(systemText, /DailyNote/);
  assert.match(systemText, /<<<\[TOOL_REQUEST\]>>>/);
  assert.doesNotMatch(systemText, /\bannotate\b/i);
  assert.doesNotMatch(systemText, /NEW_BLOCKS/);
  assert.equal(
    response.payload?.choices?.[0]?.message?.content,
    "《示例书》的本次共读日记已写入。"
  );
});

test("URL profile strips its own model prefix before upstream forwarding", async () => {
  const captured = [];
  setTestDependencies({
    pluginManager: createPluginManager([]),
    ragProcessor: {
      async processMessages(messages) {
        return messages;
      },
    },
    runtimeConfig: {
      upstreamUrl: "http://synthetic.invalid/v1",
      upstreamType: "chat",
      upstreamKey: "synthetic-upstream-key",
      defaultModel: "bridge-default-model",
      modelMap: {},
      hijackMode: "off",
      systemPrompt: "",
      debugMode: false,
    },
    fetch: async (url, options) => {
      captured.push({ url, body: JSON.parse(options.body) });
      return new Response(
        JSON.stringify({
          id: "synthetic-coreading",
          choices: [
            {
              message: {
                role: "assistant",
                content: JSON.stringify({ probe: true }),
              },
            },
          ],
        }),
        { status: 200, headers: { "content-type": "application/json" } }
      );
    },
  });

  const request = {
    method: "POST",
    path: "/v1/coreading/chat/completions",
    bridgeProfile: "coreading",
    params: {},
    query: {},
    headers: { authorization: "Bearer synthetic-local-key" },
    body: {
      model: "coreading/client-preferred-model",
      messages: [{ role: "user", content: "probe" }],
      stream: false,
    },
  };
  const response = createMockResponse();

  await bridge.__test.proxyRequest(request, response, {
    messages: request.body.messages,
    model: request.body.model,
    body: request.body,
    downstreamFormat: "chat",
  });

  assert.equal(captured.length, 1);
  assert.equal(captured[0].body.model, "client-preferred-model");
  assert.match(
    captured[0].body.messages.find((message) => message.role === "system")
      ?.content,
    /common-reading|共读|annotate/i
  );
  resetTestDependencies();
});
