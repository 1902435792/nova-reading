const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");

const {
  BridgeProfileError,
  BridgePromptError,
  MAX_PROMPT_BYTES,
  PROFILES_DIR,
  deleteProfile,
  inspectProfiles,
  isValidProfileName,
  parsePromptReference,
  readProfile,
  readSystemPrompt,
  saveProfile,
} = require("./bridgeConfig");

function expectPromptError(fn, code) {
  assert.throws(
    fn,
    (error) => error instanceof BridgePromptError && error.code === code
  );
}

test("inline prompts and safe legacy/prompts references remain compatible", (t) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "vcp-bridge-prompt-"));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  fs.mkdirSync(path.join(root, "prompts", "nested"), { recursive: true });
  fs.writeFileSync(path.join(root, "legacy.txt"), "legacy prompt\n", "utf8");
  fs.writeFileSync(
    path.join(root, "prompts", "nested", "custom.txt"),
    "custom prompt\n",
    "utf8"
  );

  assert.equal(
    readSystemPrompt("plain inline prompt", { pluginDir: root }),
    "plain inline prompt"
  );
  assert.equal(
    readSystemPrompt("legacy.txt", { pluginDir: root }),
    "legacy prompt"
  );
  assert.equal(
    readSystemPrompt("prompts/nested/custom.txt", { pluginDir: root }),
    "custom prompt"
  );
});

test("unsafe prompt paths fail closed", () => {
  const cases = [
    "C:\\a.txt",
    "C:/a.txt",
    "C:a.txt",
    "/a.txt",
    "\\a.txt",
    "\\\\server\\share\\a.txt",
    "//server/share/a.txt",
    "\\\\?\\C:\\a.txt",
    "\\\\.\\C:\\a.txt",
    "\\??\\C:\\a.txt",
    "../a.txt",
    "a/../b.txt",
    "..\\a.txt",
    "prompts/a.txt:secret",
    "prompts/a.txt.",
    "prompts/a.txt ",
    "prompts/CON.txt",
    "prompts/COM1.txt",
    "prompts/a.json",
    "prompts/a.txt.json",
    "other/a.txt",
  ];
  for (const value of cases)
    assert.throws(() => parsePromptReference(value), BridgePromptError, value);
  expectPromptError(
    () => parsePromptReference("prompts/a\0.txt"),
    "invalid_prompt_path"
  );
});

test("missing, directory, empty, invalid UTF-8 and oversized prompts fail closed", (t) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "vcp-bridge-prompt-"));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  fs.mkdirSync(path.join(root, "prompts", "folder.txt"), { recursive: true });
  fs.writeFileSync(path.join(root, "prompts", "empty.txt"), " \r\n\t", "utf8");
  fs.writeFileSync(
    path.join(root, "prompts", "invalid.txt"),
    Buffer.from([0xff, 0xfe])
  );
  fs.writeFileSync(
    path.join(root, "prompts", "large.txt"),
    Buffer.alloc(MAX_PROMPT_BYTES + 1, 0x61)
  );

  expectPromptError(
    () => readSystemPrompt("prompts/missing.txt", { pluginDir: root }),
    "prompt_not_found"
  );
  expectPromptError(
    () => readSystemPrompt("prompts/folder.txt", { pluginDir: root }),
    "prompt_not_file"
  );
  expectPromptError(
    () => readSystemPrompt("prompts/empty.txt", { pluginDir: root }),
    "prompt_empty"
  );
  expectPromptError(
    () => readSystemPrompt("prompts/invalid.txt", { pluginDir: root }),
    "prompt_invalid_utf8"
  );
  expectPromptError(
    () => readSystemPrompt("prompts/large.txt", { pluginDir: root }),
    "prompt_too_large"
  );
});

test("symlink or junction prompt paths cannot escape the allowed root", (t) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "vcp-bridge-prompt-"));
  const outside = fs.mkdtempSync(path.join(os.tmpdir(), "vcp-bridge-outside-"));
  t.after(() => {
    fs.rmSync(root, { recursive: true, force: true });
    fs.rmSync(outside, { recursive: true, force: true });
  });
  fs.mkdirSync(path.join(root, "prompts"), { recursive: true });
  fs.writeFileSync(path.join(outside, "secret.txt"), "secret", "utf8");
  const link = path.join(root, "prompts", "escape");
  fs.symlinkSync(
    outside,
    link,
    process.platform === "win32" ? "junction" : "dir"
  );

  expectPromptError(
    () => readSystemPrompt("prompts/escape/secret.txt", { pluginDir: root }),
    "prompt_reparse_forbidden"
  );
});

test("Profile names are canonical and saved Profiles are immediately readable", (t) => {
  const name = `route-smoke-${process.pid}-${Date.now()}`;
  const profilePath = path.join(PROFILES_DIR, `${name}.json`);
  t.after(() => fs.rmSync(profilePath, { force: true }));

  for (const validName of ["valid-name", "valid_name", "abc123"]) {
    assert.equal(isValidProfileName(validName), true, validName);
  }
  for (const invalidName of [
    name.toUpperCase(),
    ` ${name}`,
    `${name} `,
    "../escape",
    "name.with.dot",
  ]) {
    assert.equal(isValidProfileName(invalidName), false, invalidName);
  }

  const created = saveProfile(name, {
    displayName: "Temporary Smoke",
    systemPrompt: "first inline prompt",
    hijackMode: "prepend",
    modelOverride: "",
    responseMode: "structured",
    description: "temporary test profile",
  });
  assert.equal(created.name, name);
  assert.equal(readProfile(name).systemPrompt, "first inline prompt");
  assert.equal(readProfile(name).responseMode, "structured");

  saveProfile(name, {
    name,
    displayName: "Temporary Smoke",
    systemPrompt: "second inline prompt",
    hijackMode: "replace",
    modelOverride: "",
    responseMode: "assistant",
    description: "updated without module restart",
  });
  assert.equal(readProfile(name).systemPrompt, "second inline prompt");
  assert.equal(readProfile(name).responseMode, "assistant");
  assert.equal(deleteProfile(name), true);
  assert.equal(readProfile(name), null);
});

test("invalid responseMode is rejected instead of silently rewritten", () => {
  assert.throws(
    () =>
      saveProfile(`route-smoke-${process.pid}-${Date.now()}`, {
        systemPrompt: "inline prompt",
        responseMode: "unsupported",
      }),
    (error) =>
      error instanceof BridgeProfileError &&
      error.code === "invalid_response_mode"
  );
});

test("failed Profile replacement cleans up its temporary file", (t) => {
  const name = `route-smoke-failure-${process.pid}-${Date.now()}`;
  const destination = path.join(PROFILES_DIR, `${name}.json`);
  fs.mkdirSync(destination, { recursive: true });
  t.after(() => fs.rmSync(destination, { recursive: true, force: true }));

  assert.throws(() =>
    saveProfile(name, {
      systemPrompt: "inline prompt",
      responseMode: "passthrough",
    })
  );
  const orphanPrefix = `.${name}.json.`;
  assert.deepEqual(
    fs
      .readdirSync(PROFILES_DIR)
      .filter((fileName) => fileName.startsWith(orphanPrefix)),
    []
  );
});

test("inspectProfiles reports malformed JSON without hiding valid Profiles", (t) => {
  const suffix = `${process.pid}-${Date.now()}`;
  const validName = `route-smoke-valid-${suffix}`;
  const malformedName = `route-smoke-malformed-${suffix}`;
  const validPath = path.join(PROFILES_DIR, `${validName}.json`);
  const malformedPath = path.join(PROFILES_DIR, `${malformedName}.json`);
  const examplePath = path.join(
    PROFILES_DIR,
    `route-smoke-${suffix}.example.json`
  );
  t.after(() => {
    fs.rmSync(validPath, { force: true });
    fs.rmSync(malformedPath, { force: true });
    fs.rmSync(examplePath, { force: true });
  });

  saveProfile(validName, {
    systemPrompt: "valid inline prompt",
    responseMode: "passthrough",
  });
  fs.writeFileSync(malformedPath, "{not valid json", "utf8");
  fs.writeFileSync(examplePath, "{not valid json", "utf8");

  const report = inspectProfiles();
  assert.equal(
    report.profiles.some((profile) => profile.name === validName),
    true
  );
  const malformed = report.invalidProfiles.find(
    (profile) => profile.name === malformedName
  );
  assert.equal(malformed?.code, "invalid_profile_json");
  assert.equal(
    report.invalidProfiles.some((profile) =>
      profile.fileName.endsWith(".example.json")
    ),
    false
  );
});
