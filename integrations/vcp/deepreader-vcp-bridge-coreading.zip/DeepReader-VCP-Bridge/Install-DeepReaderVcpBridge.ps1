[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$VcpRoot
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$PackageRoot = $PSScriptRoot
$PayloadRoot = Join-Path $PackageRoot 'Plugin\VCPBridgeServer'
$ManifestPath = Join-Path $PackageRoot 'MANIFEST.sha256'

$PayloadFiles = @(
    'Plugin\VCPBridgeServer\bridgeConfig.js',
    'Plugin\VCPBridgeServer\bridgeConfig.test.js',
    'Plugin\VCPBridgeServer\bridgeserver.js',
    'Plugin\VCPBridgeServer\bridgeserver.test.js',
    'Plugin\VCPBridgeServer\config.env.example',
    'Plugin\VCPBridgeServer\coreading.txt',
    'Plugin\VCPBridgeServer\plugin-manifest.json',
    'Plugin\VCPBridgeServer\profiles\coreading.json'
)

$RequiredHostFiles = @(
    'package.json',
    'server.js',
    'modules\messageProcessor.js',
    'Plugin\RAGDiaryPlugin\RAGDiaryPlugin.js',
    'preprocessor_order.json'
)

function Resolve-ExistingDirectory([string]$PathValue) {
    $resolved = Resolve-Path -LiteralPath $PathValue -ErrorAction Stop
    $item = Get-Item -LiteralPath $resolved.Path -Force
    if (-not $item.PSIsContainer) {
        throw "VcpRoot must be an existing directory: $PathValue"
    }
    return $item.FullName
}
function Get-NormalizedRelativePath([string]$PathValue) {
    $normalized = $PathValue.Replace(
        [System.IO.Path]::AltDirectorySeparatorChar,
        [System.IO.Path]::DirectorySeparatorChar
    )
    return $normalized.TrimStart([char[]]@([System.IO.Path]::DirectorySeparatorChar))
}

$ResolvedVcpRoot = Resolve-ExistingDirectory $VcpRoot

foreach ($relativePath in $RequiredHostFiles) {
    $candidate = Join-Path $ResolvedVcpRoot $relativePath
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
        throw "The target is not a compatible VCPToolBox root; missing: $relativePath"
    }
}

if (-not (Test-Path -LiteralPath $PayloadRoot -PathType Container)) {
    throw "Package payload directory is missing: $PayloadRoot"
}
if (-not (Test-Path -LiteralPath $ManifestPath -PathType Leaf)) {
    throw "Package manifest is missing: $ManifestPath"
}

$manifest = @{}
foreach ($line in Get-Content -LiteralPath $ManifestPath -Encoding UTF8) {
    if ([string]::IsNullOrWhiteSpace($line) -or $line.StartsWith('#')) { continue }
    if ($line -notmatch '^([A-Fa-f0-9]{64})\s+\*(.+)$') {
        throw "Invalid MANIFEST.sha256 line: $line"
    }
    $manifest[(Get-NormalizedRelativePath $Matches[2])] = $Matches[1].ToUpperInvariant()
}

foreach ($relativePath in $PayloadFiles) {
    $normalized = Get-NormalizedRelativePath $relativePath
    $sourcePath = Join-Path $PackageRoot $normalized
    if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) {
        throw "Package payload file is missing: $normalized"
    }
    if (-not $manifest.ContainsKey($normalized)) {
        throw "Package manifest has no hash for: $normalized"
    }
    $actualHash = (Get-FileHash -LiteralPath $sourcePath -Algorithm SHA256).Hash.ToUpperInvariant()
    if ($actualHash -ne $manifest[$normalized]) {
        throw "Package hash mismatch: $normalized"
    }
}

Push-Location $ResolvedVcpRoot
try {
    foreach ($dependency in @('express', 'dotenv', 'chokidar')) {
        & node -e "require.resolve('$dependency')" | Out-Null
        if ($LASTEXITCODE -ne 0) {
            throw "Required Node dependency is unavailable from the VCP root: $dependency"
        }
    }
}
finally {
    Pop-Location
}

$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupRoot = Join-Path $ResolvedVcpRoot "backups\deepreader-vcp-bridge-$timestamp"
$stateEntries = [System.Collections.Generic.List[object]]::new()

if ($WhatIfPreference) {
    Write-Host '[WhatIf] Validation passed. The following files would be installed:'
    $PayloadFiles | ForEach-Object { Write-Host "  $_" }
    Write-Host "[WhatIf] Backup directory would be: $backupRoot"
    return
}

New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null

# Back up every existing target and persist complete rollback state before the
# first payload write. A copy failure can then still be recovered safely.
foreach ($relativePath in $PayloadFiles) {
    $normalized = Get-NormalizedRelativePath $relativePath
    $targetPath = Join-Path $ResolvedVcpRoot $normalized
    $existed = Test-Path -LiteralPath $targetPath -PathType Leaf

    $stateEntries.Add([pscustomobject]@{
        relativePath = $normalized.Replace(
            [System.IO.Path]::DirectorySeparatorChar,
            [System.IO.Path]::AltDirectorySeparatorChar
        )
        existed = [bool]$existed
    })

    if ($existed) {
        $backupPath = Join-Path $backupRoot $normalized
        New-Item -ItemType Directory -Path (Split-Path -Parent $backupPath) -Force | Out-Null
        Copy-Item -LiteralPath $targetPath -Destination $backupPath -Force
    }
}

$state = [pscustomobject]@{
    schemaVersion = 1
    installedAt = (Get-Date).ToString('o')
    vcpRoot = $ResolvedVcpRoot
    packageManifest = 'MANIFEST.sha256'
    files = $stateEntries
}
$state | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $backupRoot 'installation-state.json') -Encoding UTF8

foreach ($relativePath in $PayloadFiles) {
    $normalized = Get-NormalizedRelativePath $relativePath
    $sourcePath = Join-Path $PackageRoot $normalized
    $targetPath = Join-Path $ResolvedVcpRoot $normalized
    New-Item -ItemType Directory -Path (Split-Path -Parent $targetPath) -Force | Out-Null
    Copy-Item -LiteralPath $sourcePath -Destination $targetPath -Force
}

Write-Host ''
Write-Host 'DeepReader VCP Bridge payload installed successfully.' -ForegroundColor Green
Write-Host "Backup directory: $backupRoot"
Write-Host 'No config.env or bridge-config.json was changed.'
Write-Host 'No process was stopped or restarted.'
Write-Host 'Read README.md, verify VCP configuration, then identify the exact 3100/PM2 process before manually restarting it.'
